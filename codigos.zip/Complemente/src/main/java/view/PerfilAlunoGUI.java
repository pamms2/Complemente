package view;

import controller.AlunoController;
import controller.AtividadeController;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import model.Aluno;
import model.Atividade;
import model.TotalAtividade;
import view.AtualizarAlunoGUI;
import view.ListaAtividadesGUI;

public class PerfilAlunoGUI extends javax.swing.JFrame {
    
    private AlunoController alunoController = new AlunoController();
    private static Aluno alunoAtual;
    private static PerfilAlunoGUI perfilAlunoUnic;
    
    private PerfilAlunoGUI() {
        initComponents();
        this.setExtendedState(PerfilAlunoGUI.MAXIMIZED_BOTH);
    }
    
    public static PerfilAlunoGUI geraPerfilAlunoGUI(Aluno aluno) {        
        if(perfilAlunoUnic == null) {
            perfilAlunoUnic = new PerfilAlunoGUI();
        }
              
        alunoAtual = aluno; 
        perfilAlunoUnic.preencherDadosAluno();
        return perfilAlunoUnic;
    }
    
    private void preencherDadosAluno() {
        if(alunoAtual != null) {
            jLabelNomePreenchido.setText(alunoAtual.getNome());
            jLabelRAPreenchido.setText(String.valueOf(alunoAtual.getRA()));
            jLabelEmailPreenchido.setText(alunoAtual.getEmail());
            jLabelCursoPreenchido.setText(alunoAtual.getCurso() + " - " + alunoAtual.getCodCurso());
        
            AtividadeController atvController = new AtividadeController();
            List<Atividade> atividades = atvController.consultarAtividadesPorRA(alunoAtual.getRA());
            alunoAtual.setAtividades(atividades);
            if(atividades != null) {
                TotalAtividade total = new TotalAtividade();
                total.calcularPontos(atividades);
                atualizarTabelaGruposComTotais(total);
            }
            TotalAtividade total = new TotalAtividade();
            total.calcularPontos(atividades);
            atualizarTabelaGruposComTotais(total);
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelPerfilAluno = new javax.swing.JLabel();
        jButtonAtividade = new javax.swing.JButton();
        jLabelNome = new javax.swing.JLabel();
        jLabelRA = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jLabelCurso = new javax.swing.JLabel();
        jLabelNomePreenchido = new javax.swing.JLabel();
        jLabelRAPreenchido = new javax.swing.JLabel();
        jLabelEmailPreenchido = new javax.swing.JLabel();
        jLabelCursoPreenchido = new javax.swing.JLabel();
        jButtonAtualizar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableGrupos = new javax.swing.JTable();
        jLabelResumo = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButtonListaAtividade = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonSairConta = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelPerfilAluno.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelPerfilAluno.setText("PERFIL DO ALUNO");

        jButtonAtividade.setText("Cadastrar Atividade");
        jButtonAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtividadeActionPerformed(evt);
            }
        });

        jLabelNome.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelNome.setText("Nome:");

        jLabelRA.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelRA.setText("RA:");

        jLabelEmail.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelEmail.setText("E-mail:");

        jLabelCurso.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCurso.setText("Curso:");

        jLabelNomePreenchido.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelNomePreenchido.setText("Nome preenchido");

        jLabelRAPreenchido.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelRAPreenchido.setText("RA preenchido");

        jLabelEmailPreenchido.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelEmailPreenchido.setText("E-mail preenchido");

        jLabelCursoPreenchido.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCursoPreenchido.setText("curso preenchido");

        jButtonAtualizar.setText("Atualizar dados");
        jButtonAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtualizarActionPerformed(evt);
            }
        });

        jTableGrupos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Grupo 1", "", null, null},
                {"Grupo 2", null, null, null},
                {"Grupo 3", null, null, null},
                {"Total", null, null, null}
            },
            new String [] {
                "", "Pontos mínimos", "Pontos cumpridos", "Aptidão"
            }
        ));
        jScrollPane1.setViewportView(jTableGrupos);

        jLabelResumo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelResumo.setText("Resumo de Atividades");

        jButton1.setText("Excluir Perfil");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButtonListaAtividade.setText("Visualizar Lista de Atividades");
        jButtonListaAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonListaAtividadeActionPerformed(evt);
            }
        });

        jButtonEditar.setText("Editar Atividade");
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });

        jButtonSairConta.setText("Sair da conta");
        jButtonSairConta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairContaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelCurso, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelNome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelRA, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jButtonSairConta)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelRAPreenchido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelNomePreenchido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelEmailPreenchido, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                    .addComponent(jLabelPerfilAluno, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap(206, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jButtonAtividade)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButtonListaAtividade))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGap(144, 144, 144)
                                    .addComponent(jLabelResumo))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(77, 77, 77)
                                    .addComponent(jLabelCursoPreenchido, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButtonAtualizar))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(34, 34, 34))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonSairConta)
                    .addComponent(jLabelPerfilAluno))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(jLabelNomePreenchido))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelRA)
                    .addComponent(jLabelRAPreenchido))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelEmail)
                    .addComponent(jLabelEmailPreenchido))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCurso)
                    .addComponent(jLabelCursoPreenchido, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonAtualizar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                .addComponent(jLabelResumo, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonAtividade)
                    .addComponent(jButtonListaAtividade))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonEditar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(29, 29, 29))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtividadeActionPerformed
        abreCadastrarAtividadeGUI();
    }//GEN-LAST:event_jButtonAtividadeActionPerformed

    private void jButtonAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtualizarActionPerformed
        abreAtulizarAlunoGUI();
    }//GEN-LAST:event_jButtonAtualizarActionPerformed

    private void jButtonListaAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonListaAtividadeActionPerformed
        abreListaAtividadesGUI();
    }//GEN-LAST:event_jButtonListaAtividadeActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        excluirAluno();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
        abreCRUDAtividadesGUI();
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonSairContaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairContaActionPerformed
        voltarLoginGUI();
    }//GEN-LAST:event_jButtonSairContaActionPerformed

    public void voltarLoginGUI() {
        int resposta = 
        JOptionPane.showConfirmDialog(
            null,
            "Deseja realmente sair da conta?",
            "Sair",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if(resposta == JOptionPane.YES_OPTION) {
            LoginGUI.geraLoginGUI().setVisible(true);
            dispose();
            alunoAtual = null;
            perfilAlunoUnic = null;
        }
    }
    
    public void abreCRUDAtividadesGUI() {
        CRUDAtividadesGUI.geraCRUDAtividadesGUI(alunoAtual).setVisible(true);
        dispose();
    }
    
    private void atualizarTabelaGruposComTotais(TotalAtividade total) {
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) jTableGrupos.getModel();
        model.setRowCount(0); // limpa a tabela
        jTableGrupos.setRowHeight(22);

        String aptidaoG1;
        if(total.getSomaG1() >= 10) {
            aptidaoG1 = "OK";
        } else {
            aptidaoG1 = "X";
        }
        model.addRow(new Object[]{"Grupo 1", "10", total.getSomaG1(), aptidaoG1});
        
        String aptidaoG2;
        if(total.getSomaG2() >= 10) {
            aptidaoG2 = "OK";
        } else {
            aptidaoG2 = "X";
        }
        model.addRow(new Object[]{"Grupo 2", "10", total.getSomaG2(), aptidaoG2});
        
        String aptidaoG3;
        if(total.getSomaG3() >= 10) {
            aptidaoG3 = "OK";
        } else {
            aptidaoG3 = "X";
        }
        model.addRow(new Object[]{"Grupo 3", "10", total.getSomaG3(), aptidaoG3});     
        
        String aptidaoGeral;
        if(total.getSomaPontosTotal() >= 60) {
            aptidaoGeral = "OK";
        } else {
            aptidaoGeral = "X";
        }
        model.addRow(new Object[]{"Total", "60", total.getSomaPontosTotal(), aptidaoGeral});
    }

    
    public void excluirAluno() {
        int resposta = JOptionPane.showConfirmDialog(
            null,
            "Deseja excluir seu perfil?",
            "Exclusão de conta",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (resposta == JOptionPane.YES_OPTION) {
            JPasswordField senhaField = new JPasswordField();
            Object[] mensagem = {
                "Confirme sua senha:", senhaField
            };

            int confirmar = JOptionPane.showConfirmDialog(
                null,
                mensagem,
                "Confirmar exclusão",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
            );

            if (confirmar == JOptionPane.OK_OPTION) {
                String senha = new String(senhaField.getPassword());

                if (senha.equals(alunoAtual.getSenha())) {
                    try {
                        // Depois exclua o aluno
                        alunoController.excluirAluno(alunoAtual.getRA(), senha);

                        JOptionPane.showMessageDialog(
                            null,
                            "Exclusão realizada com sucesso!",
                            "Exclusão de conta",
                            JOptionPane.INFORMATION_MESSAGE
                        );
                        
                        LoginGUI.geraLoginGUI().setVisible(true);
                        dispose();
       

                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(
                            null,
                            "Erro ao excluir o aluno: " + e.getMessage(),
                            "Erro SQL",
                            JOptionPane.ERROR_MESSAGE
                        );
                    }
                } else {
                    JOptionPane.showMessageDialog(
                        null,
                        "Senha incorreta.",
                        "Erro",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "Exclusão cancelada!",
                    "Cancelamento",
                    JOptionPane.INFORMATION_MESSAGE
                );
            }
        }

    }
    
    public void abreListaAtividadesGUI() {
        ListaAtividadesGUI.geraListaAtividadeGUI(alunoAtual).setVisible(true);
        dispose();
    }
    
    public void abreCadastrarAtividadeGUI() {
        CadastrarAtividadeGUI.geraCadastrarAtividadeGUI(alunoAtual).setVisible(true);
        dispose();
    }
    
    public void abreAtulizarAlunoGUI() {
        AtualizarAlunoGUI.geraAtualizarAlunoGUI(alunoAtual).setVisible(true);
        dispose();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonAtividade;
    private javax.swing.JButton jButtonAtualizar;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonListaAtividade;
    private javax.swing.JButton jButtonSairConta;
    private javax.swing.JLabel jLabelCurso;
    private javax.swing.JLabel jLabelCursoPreenchido;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelEmailPreenchido;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelNomePreenchido;
    private javax.swing.JLabel jLabelPerfilAluno;
    private javax.swing.JLabel jLabelRA;
    private javax.swing.JLabel jLabelRAPreenchido;
    private javax.swing.JLabel jLabelResumo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableGrupos;
    // End of variables declaration//GEN-END:variables
}
