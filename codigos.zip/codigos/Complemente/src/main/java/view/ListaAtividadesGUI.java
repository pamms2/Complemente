package view;

import controller.AtividadeController;
import controller.GerarRelatorio;
import java.awt.Component;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import model.Aluno;
import model.Atividade;
import model.Relatorio;
import model.TotalAtividade;

public class ListaAtividadesGUI extends javax.swing.JFrame implements Relatorio{
    
    private static Aluno alunoAtual;
    private static ListaAtividadesGUI selecaoAtividadeUnic;
    

    public static ListaAtividadesGUI geraListaAtividadeGUI(Aluno aluno) {
        alunoAtual = aluno;
        if (selecaoAtividadeUnic == null) {
            selecaoAtividadeUnic = new ListaAtividadesGUI();
        }

        AtividadeController atvController = new AtividadeController();
        List<Atividade> atividades = atvController.consultarAtividadesPorRA(alunoAtual.getRA());
        alunoAtual.setAtividades(atividades);

        selecaoAtividadeUnic.exibirAtividadesDoAluno(alunoAtual); 

        return selecaoAtividadeUnic;
    }


    public void exibirAtividadesDoAluno(Aluno aluno) {
        jPanelGrupo1.removeAll();
        jPanelGrupo2.removeAll();
        jPanelGrupo3.removeAll();

        for (Atividade atividade : aluno.getAtividades()) {
            adicionarAtividade(atividade);
        }

        jPanelGrupo1.revalidate();
        jPanelGrupo1.repaint();

        jPanelGrupo2.revalidate();
        jPanelGrupo2.repaint();

        jPanelGrupo3.revalidate();
        jPanelGrupo3.repaint();
        
        // Exibe somente os grupos que têm atividades
        if (!aluno.getAtividades().isEmpty()) {
            for (Atividade atv : aluno.getAtividades()) {
                switch (atv.getGrupo()) {
                    case 1 -> jPanelGrupo1.setVisible(true);
                    case 2 -> jPanelGrupo2.setVisible(true);
                    case 3 -> jPanelGrupo3.setVisible(true);
                }
            }
        }
    }
  
    public ListaAtividadesGUI() {
        initComponents();
        jPanelGrupo1.setVisible(false);
        jPanelGrupo2.setVisible(false);
        jPanelGrupo3.setVisible(false);
        
        jPanelGrupo1.setLayout(new BoxLayout(jPanelGrupo1, BoxLayout.Y_AXIS));
        jPanelGrupo2.setLayout(new BoxLayout(jPanelGrupo2, BoxLayout.Y_AXIS));
        jPanelGrupo3.setLayout(new BoxLayout(jPanelGrupo3, BoxLayout.Y_AXIS));

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonGerarRelatorio = new javax.swing.JButton();
        jLabelTitulo = new javax.swing.JLabel();
        jLabelGrupo1 = new javax.swing.JLabel();
        jLabelGrupo2 = new javax.swing.JLabel();
        jLabelGrupo3 = new javax.swing.JLabel();
        jButtonAdicionarAtividade = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanelGrupo2 = new javax.swing.JPanel();
        jLabelTipo3 = new javax.swing.JLabel();
        jLabelDescricao3 = new javax.swing.JLabel();
        jLabelPeriodo3 = new javax.swing.JLabel();
        jLabelDuracao3 = new javax.swing.JLabel();
        jLabelTipoPreenchido3 = new javax.swing.JLabel();
        jLabelDescricaoPreenchido3 = new javax.swing.JLabel();
        jLabelInicio3 = new javax.swing.JLabel();
        jLabelQtd3 = new javax.swing.JLabel();
        jLabelA3 = new javax.swing.JLabel();
        jLabelTermino3 = new javax.swing.JLabel();
        jLabelTempo1 = new javax.swing.JLabel();
        jLabelPontos2 = new javax.swing.JLabel();
        jLabelQtdPontos3 = new javax.swing.JLabel();
        jCheckBoxPrimeira3 = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanelGrupo1 = new javax.swing.JPanel();
        jLabelTipo4 = new javax.swing.JLabel();
        jLabelDescricao4 = new javax.swing.JLabel();
        jLabelPeriodo4 = new javax.swing.JLabel();
        jLabelDuracao4 = new javax.swing.JLabel();
        jLabelTipoPreenchido4 = new javax.swing.JLabel();
        jLabelDescricaoPreenchido4 = new javax.swing.JLabel();
        jLabelInicio4 = new javax.swing.JLabel();
        jLabelQtd4 = new javax.swing.JLabel();
        jLabelA4 = new javax.swing.JLabel();
        jLabelTermino4 = new javax.swing.JLabel();
        jLabelTempo2 = new javax.swing.JLabel();
        jLabelPontos3 = new javax.swing.JLabel();
        jLabelQtdPontos4 = new javax.swing.JLabel();
        jCheckBoxPrimeira4 = new javax.swing.JCheckBox();
        jScrollPane4 = new javax.swing.JScrollPane();
        jPanelGrupo3 = new javax.swing.JPanel();
        jLabelTipo5 = new javax.swing.JLabel();
        jLabelDescricao5 = new javax.swing.JLabel();
        jLabelPeriodo5 = new javax.swing.JLabel();
        jLabelDuracao5 = new javax.swing.JLabel();
        jLabelTipoPreenchido5 = new javax.swing.JLabel();
        jLabelDescricaoPreenchido5 = new javax.swing.JLabel();
        jLabelInicio5 = new javax.swing.JLabel();
        jLabelQtd5 = new javax.swing.JLabel();
        jLabelA5 = new javax.swing.JLabel();
        jLabelTermino5 = new javax.swing.JLabel();
        jLabelTempo3 = new javax.swing.JLabel();
        jLabelPontos4 = new javax.swing.JLabel();
        jLabelQtdPontos5 = new javax.swing.JLabel();
        jCheckBoxPrimeira5 = new javax.swing.JCheckBox();
        jButtonVoltar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonGerarRelatorio.setText("Gerar Relatório ");
        jButtonGerarRelatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGerarRelatorioActionPerformed(evt);
            }
        });

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTitulo.setText("Lista de Atividades");

        jLabelGrupo1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo1.setText("Grupo 1");

        jLabelGrupo2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo2.setText("Grupo 2");

        jLabelGrupo3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo3.setText("Grupo 3");

        jButtonAdicionarAtividade.setText("Adicionar Atividade");
        jButtonAdicionarAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdicionarAtividadeActionPerformed(evt);
            }
        });

        jLabelTipo3.setText("Tipo:");
        jLabelTipo3.setName("lblT"); // NOI18N

        jLabelDescricao3.setText("Descrição:");
        jLabelDescricao3.setName("lblD"); // NOI18N

        jLabelPeriodo3.setText("Período:");
        jLabelPeriodo3.setName("lblPe"); // NOI18N

        jLabelDuracao3.setText("Duração:");
        jLabelDuracao3.setName("lblDu"); // NOI18N

        jLabelTipoPreenchido3.setText("Tipo preenchido");
        jLabelTipoPreenchido3.setName("lblTipo"); // NOI18N

        jLabelDescricaoPreenchido3.setText("Descrição preenchida");
        jLabelDescricaoPreenchido3.setName("lblDescricao"); // NOI18N

        jLabelInicio3.setText("01/01/2001");
        jLabelInicio3.setName("lblP1"); // NOI18N

        jLabelQtd3.setText("Qtd");
        jLabelQtd3.setName("lblQtd"); // NOI18N

        jLabelA3.setText("a");
        jLabelA3.setName("lbla"); // NOI18N

        jLabelTermino3.setText("31/12/2001");
        jLabelTermino3.setName("lblP2"); // NOI18N

        jLabelTempo1.setText("Tempo");
        jLabelTempo1.setName("lblTempo"); // NOI18N

        jLabelPontos2.setText("Pontos:");
        jLabelPontos2.setName("lblP"); // NOI18N

        jLabelQtdPontos3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQtdPontos3.setText("10");
        jLabelQtdPontos3.setName("lblPontos"); // NOI18N

        jCheckBoxPrimeira3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxPrimeira3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelGrupo2Layout = new javax.swing.GroupLayout(jPanelGrupo2);
        jPanelGrupo2.setLayout(jPanelGrupo2Layout);
        jPanelGrupo2Layout.setHorizontalGroup(
            jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                .addComponent(jCheckBoxPrimeira3)
                .addGap(23, 23, 23)
                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                        .addComponent(jLabelDuracao3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelQtd3, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                        .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabelDescricao3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabelTipo3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabelPeriodo3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDescricaoPreenchido3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                                .addComponent(jLabelInicio3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                                        .addComponent(jLabelTempo1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                                        .addComponent(jLabelA3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabelTermino3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabelQtdPontos3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                                .addComponent(jLabelTipoPreenchido3, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                                .addComponent(jLabelPontos2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanelGrupo2Layout.setVerticalGroup(
            jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTipo3)
                    .addComponent(jLabelTipoPreenchido3)
                    .addComponent(jLabelPontos2))
                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelDescricaoPreenchido3)
                            .addComponent(jLabelDescricao3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelPeriodo3)
                                .addComponent(jLabelInicio3)
                                .addComponent(jLabelA3)
                                .addComponent(jLabelTermino3))
                            .addComponent(jLabelQtdPontos3)))
                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jCheckBoxPrimeira3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDuracao3)
                    .addComponent(jLabelQtd3)
                    .addComponent(jLabelTempo1))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanelGrupo2);

        jLabelTipo4.setText("Tipo:");
        jLabelTipo4.setName("lblT"); // NOI18N

        jLabelDescricao4.setText("Descrição:");
        jLabelDescricao4.setName("lblD"); // NOI18N

        jLabelPeriodo4.setText("Período:");
        jLabelPeriodo4.setName("lblPe"); // NOI18N

        jLabelDuracao4.setText("Duração:");
        jLabelDuracao4.setName("lblDu"); // NOI18N

        jLabelTipoPreenchido4.setText("Tipo preenchido");
        jLabelTipoPreenchido4.setName("lblTipo"); // NOI18N

        jLabelDescricaoPreenchido4.setText("Descrição preenchida");
        jLabelDescricaoPreenchido4.setName("lblDescricao"); // NOI18N

        jLabelInicio4.setText("01/01/2001");
        jLabelInicio4.setName("lblP1"); // NOI18N

        jLabelQtd4.setText("Qtd");
        jLabelQtd4.setName("lblQtd"); // NOI18N

        jLabelA4.setText("a");
        jLabelA4.setName("lbla"); // NOI18N

        jLabelTermino4.setText("31/12/2001");
        jLabelTermino4.setName("lblP2"); // NOI18N

        jLabelTempo2.setText("Tempo");
        jLabelTempo2.setName("lblTempo"); // NOI18N

        jLabelPontos3.setText("Pontos:");
        jLabelPontos3.setName("lblP"); // NOI18N

        jLabelQtdPontos4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQtdPontos4.setText("10");
        jLabelQtdPontos4.setName("lblPontos"); // NOI18N

        jCheckBoxPrimeira4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxPrimeira4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelGrupo1Layout = new javax.swing.GroupLayout(jPanelGrupo1);
        jPanelGrupo1.setLayout(jPanelGrupo1Layout);
        jPanelGrupo1Layout.setHorizontalGroup(
            jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                .addComponent(jCheckBoxPrimeira4)
                .addGap(23, 23, 23)
                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                        .addComponent(jLabelDuracao4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelQtd4, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                        .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabelDescricao4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabelTipo4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabelPeriodo4, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDescricaoPreenchido4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                                .addComponent(jLabelInicio4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                                        .addComponent(jLabelTempo2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                                        .addComponent(jLabelA4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabelTermino4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabelQtdPontos4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                                .addComponent(jLabelTipoPreenchido4, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                                .addComponent(jLabelPontos3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanelGrupo1Layout.setVerticalGroup(
            jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTipo4)
                    .addComponent(jLabelTipoPreenchido4)
                    .addComponent(jLabelPontos3))
                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelDescricaoPreenchido4)
                            .addComponent(jLabelDescricao4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelPeriodo4)
                                .addComponent(jLabelInicio4)
                                .addComponent(jLabelA4)
                                .addComponent(jLabelTermino4))
                            .addComponent(jLabelQtdPontos4)))
                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jCheckBoxPrimeira4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDuracao4)
                    .addComponent(jLabelQtd4)
                    .addComponent(jLabelTempo2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabelTipo4.getAccessibleContext().setAccessibleName("lblTipo");
        jLabelTipoPreenchido4.getAccessibleContext().setAccessibleName("lblTipoP");

        jScrollPane2.setViewportView(jPanelGrupo1);

        jLabelTipo5.setText("Tipo:");
        jLabelTipo5.setName("lblT"); // NOI18N

        jLabelDescricao5.setText("Descrição:");
        jLabelDescricao5.setName("lblD"); // NOI18N

        jLabelPeriodo5.setText("Período:");
        jLabelPeriodo5.setName("lblPe"); // NOI18N

        jLabelDuracao5.setText("Duração:");
        jLabelDuracao5.setName("lblDu"); // NOI18N

        jLabelTipoPreenchido5.setText("Tipo preenchido");
        jLabelTipoPreenchido5.setName("lblTipo"); // NOI18N

        jLabelDescricaoPreenchido5.setText("Descrição preenchida");
        jLabelDescricaoPreenchido5.setName("lblDescricao"); // NOI18N

        jLabelInicio5.setText("01/01/2001");
        jLabelInicio5.setName("lblP1"); // NOI18N

        jLabelQtd5.setText("Qtd");
        jLabelQtd5.setName("lblQtd"); // NOI18N

        jLabelA5.setText("a");
        jLabelA5.setName("lbla"); // NOI18N

        jLabelTermino5.setText("31/12/2001");
        jLabelTermino5.setName("lblP2"); // NOI18N

        jLabelTempo3.setText("Tempo");
        jLabelTempo3.setName("lblTempo"); // NOI18N

        jLabelPontos4.setText("Pontos:");
        jLabelPontos4.setName("lblP"); // NOI18N

        jLabelQtdPontos5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQtdPontos5.setText("10");
        jLabelQtdPontos5.setName("lblPontos"); // NOI18N

        jCheckBoxPrimeira5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxPrimeira5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelGrupo3Layout = new javax.swing.GroupLayout(jPanelGrupo3);
        jPanelGrupo3.setLayout(jPanelGrupo3Layout);
        jPanelGrupo3Layout.setHorizontalGroup(
            jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                .addComponent(jCheckBoxPrimeira5)
                .addGap(23, 23, 23)
                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                        .addComponent(jLabelDuracao5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelQtd5, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                        .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabelDescricao5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabelTipo5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabelPeriodo5, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDescricaoPreenchido5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                                .addComponent(jLabelInicio5, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                                        .addComponent(jLabelTempo3, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                                        .addComponent(jLabelA5, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabelTermino5, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabelQtdPontos5, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                                .addComponent(jLabelTipoPreenchido5, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                                .addComponent(jLabelPontos4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanelGrupo3Layout.setVerticalGroup(
            jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTipo5)
                    .addComponent(jLabelTipoPreenchido5)
                    .addComponent(jLabelPontos4))
                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelDescricaoPreenchido5)
                            .addComponent(jLabelDescricao5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelPeriodo5)
                                .addComponent(jLabelInicio5)
                                .addComponent(jLabelA5)
                                .addComponent(jLabelTermino5))
                            .addComponent(jLabelQtdPontos5)))
                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jCheckBoxPrimeira5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDuracao5)
                    .addComponent(jLabelQtd5)
                    .addComponent(jLabelTempo3))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jScrollPane4.setViewportView(jPanelGrupo3);

        jButtonVoltar.setText("Voltar ");
        jButtonVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonVoltarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelGrupo2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelGrupo1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelGrupo3, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButtonAdicionarAtividade)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jButtonVoltar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButtonGerarRelatorio))))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(153, Short.MAX_VALUE)
                .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(153, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jLabelTitulo)
                .addGap(29, 29, 29)
                .addComponent(jLabelGrupo1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabelGrupo2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabelGrupo3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(jButtonAdicionarAtividade)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonGerarRelatorio)
                    .addComponent(jButtonVoltar))
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGerarRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGerarRelatorioActionPerformed
        gerarRelatorio();
    }//GEN-LAST:event_jButtonGerarRelatorioActionPerformed

    private void jButtonAdicionarAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdicionarAtividadeActionPerformed
        abreCadastroAtividadeGUI();
    }//GEN-LAST:event_jButtonAdicionarAtividadeActionPerformed

    private void jCheckBoxPrimeira3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxPrimeira3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxPrimeira3ActionPerformed

    private void jCheckBoxPrimeira4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxPrimeira4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxPrimeira4ActionPerformed

    private void jCheckBoxPrimeira5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxPrimeira5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxPrimeira5ActionPerformed

    private void jButtonVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonVoltarActionPerformed
        abrePerfilAlunoGUI();
    }//GEN-LAST:event_jButtonVoltarActionPerformed

    public void abrePerfilAlunoGUI() {
        PerfilAlunoGUI.geraPerfilAlunoGUI(alunoAtual).setVisible(true);
        dispose();
    }
    
    public void gerarRelatorio() {
        try {
            List<Atividade> selecionadas = getAtividadesSelecionadas();

            TotalAtividade total = new TotalAtividade();
            total.calcularPontos(selecionadas);

            String erros = total.verificarErrosDeLimites();
            if (!erros.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Não foi possível gerar o relatório:\n\n" + erros,
                        "Limites não atendidos",
                        javax.swing.JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            alunoAtual.setAtividades(selecionadas);
            alunoAtual.setTotalAtividade(total);
            GerarRelatorio.gerar(alunoAtual);

            javax.swing.JOptionPane.showMessageDialog(this,
                    "Relatório gerado com sucesso!"
            );

        } catch (Exception ex) {
            ex.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Erro ao gerar o relatório:\n" + ex.getMessage()
            );
        }
    }
    
    public void abreCadastroAtividadeGUI() {
        CadastroAtividadeGUI.geraCadastroAtividadeGUI(alunoAtual).setVisible(true);
        dispose();
    }
    
    public void adicionarAtividade(Atividade atividade) {
        JPanel modelo;
        
        switch(atividade.getGrupo()) {
            case 1:
                modelo = jPanelGrupo1;
                break;
                
            case 2:
                modelo = jPanelGrupo2;
                break;
                
            case 3:
                modelo = jPanelGrupo3;
                break;
                
            default:
                throw new IllegalArgumentException("Grupo inválido!");
        }
        
        
        JPanel novoPanel = criarPainelAtividade(atividade);

        modelo.add(novoPanel);  
        modelo.revalidate();
        modelo.repaint();
    }
    
    private void preencherDadosPainel(JPanel painel, Atividade atividade) {
        for(Component comp : painel.getComponents()) {
            if(comp instanceof JLabel lbl) {
                switch(lbl.getName()) {
                    case "lblTipo":
                        lbl.setText(atividade.getTipo());
                        break;
                        
                    case "lblPontos":
                        lbl.setText(String.valueOf(atividade.getPontos()));
                        break;
                        
                    case "lblDescricao":
                        lbl.setText(atividade.getCarac().getDescricao());
                        break;
                        
                    case "lblP1":
                        lbl.setText(String.valueOf(atividade.getCarac().getInicio()));
                        break;
                    
                    case "lblP2":
                        lbl.setText(String.valueOf(atividade.getCarac().getFim()));
                        break;
                       
                    case "lblQtd":
                        lbl.setText(String.valueOf(atividade.getCarac().getDuracao()));
                        break;
                        
                    case "lblTempo":
                        lbl.setText(atividade.getCarac().getUnidade());
                        break;
                }
            }
        }
    }
    
    private JPanel criarPainelAtividade(Atividade atividade) {
        JPanel painel = new JPanel();
        GroupLayout layout = new GroupLayout(painel);
        painel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        // Componentes
        JLabel lblTipo = new JLabel("Tipo:");
        JLabel lblTipoPreenchido = new JLabel(atividade.getTipo());
        JLabel lblPontos = new JLabel("Pontos: " + atividade.getPontos());

        JLabel lblDescricao = new JLabel("Descrição:");
        JLabel lblDescricaoPreenchido = new JLabel(atividade.getCarac().getDescricao());

        JLabel lblPeriodo = new JLabel("Período:");
        JLabel lblInicio = new JLabel(atividade.getCarac().getInicio().toString());
        JLabel lblA = new JLabel("a");
        JLabel lblTermino = new JLabel(atividade.getCarac().getFim().toString());

        JLabel lblQtdPontos = new JLabel("Qtd. Pontos: " + atividade.getPontos());

        JCheckBox chkSelecionado = new JCheckBox("Selecionar");

        JLabel lblDuracao = new JLabel("Duração:");
        JLabel lblQtd = new JLabel(String.valueOf(atividade.getCarac().getDuracao()));
        JLabel lblTempo = new JLabel(atividade.getCarac().getUnidade());

        // Horizontal Group
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(lblTipo)
                    .addComponent(lblTipoPreenchido)
                    .addComponent(lblPontos))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(lblDescricao)
                    .addComponent(lblDescricaoPreenchido))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(lblPeriodo)
                    .addComponent(lblInicio)
                    .addComponent(lblA)
                    .addComponent(lblTermino)
                    .addComponent(lblQtdPontos)
                    .addComponent(chkSelecionado))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(lblDuracao)
                    .addComponent(lblQtd)
                    .addComponent(lblTempo))
        );

        // Vertical Group
        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTipo)
                    .addComponent(lblTipoPreenchido)
                    .addComponent(lblPontos))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescricao)
                    .addComponent(lblDescricaoPreenchido))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPeriodo)
                    .addComponent(lblInicio)
                    .addComponent(lblA)
                    .addComponent(lblTermino)
                    .addComponent(lblQtdPontos)
                    .addComponent(chkSelecionado))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDuracao)
                    .addComponent(lblQtd)
                    .addComponent(lblTempo))
        );

        painel.setBorder(BorderFactory.createEtchedBorder());
        
        painel.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, painel.getPreferredSize().height));
        painel.setAlignmentX(Component.LEFT_ALIGNMENT);

        painel.putClientProperty("atividade", atividade);
        return painel;
    }
    
    public List<Atividade> getAtividadesSelecionadas() {
        List<Atividade> selecionadas = new ArrayList<>();

        for (JPanel grupo : List.of(jPanelGrupo1, jPanelGrupo2, jPanelGrupo3)) {
            for (Component comp : grupo.getComponents()) {
                if (comp instanceof JPanel painel) {
                    for (Component c : painel.getComponents()) {
                        if (c instanceof JCheckBox chk && chk.isSelected()) {
                            Atividade atv = (Atividade) painel.getClientProperty("atividade");
                            if (atv != null) {
                                selecionadas.add(atv);
                            }
                        }
                    }
                }
            }
        }

        return selecionadas;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdicionarAtividade;
    private javax.swing.JButton jButtonGerarRelatorio;
    private javax.swing.JButton jButtonVoltar;
    private javax.swing.JCheckBox jCheckBoxPrimeira3;
    private javax.swing.JCheckBox jCheckBoxPrimeira4;
    private javax.swing.JCheckBox jCheckBoxPrimeira5;
    private javax.swing.JLabel jLabelA3;
    private javax.swing.JLabel jLabelA4;
    private javax.swing.JLabel jLabelA5;
    private javax.swing.JLabel jLabelDescricao3;
    private javax.swing.JLabel jLabelDescricao4;
    private javax.swing.JLabel jLabelDescricao5;
    private javax.swing.JLabel jLabelDescricaoPreenchido3;
    private javax.swing.JLabel jLabelDescricaoPreenchido4;
    private javax.swing.JLabel jLabelDescricaoPreenchido5;
    private javax.swing.JLabel jLabelDuracao3;
    private javax.swing.JLabel jLabelDuracao4;
    private javax.swing.JLabel jLabelDuracao5;
    private javax.swing.JLabel jLabelGrupo1;
    private javax.swing.JLabel jLabelGrupo2;
    private javax.swing.JLabel jLabelGrupo3;
    private javax.swing.JLabel jLabelInicio3;
    private javax.swing.JLabel jLabelInicio4;
    private javax.swing.JLabel jLabelInicio5;
    private javax.swing.JLabel jLabelPeriodo3;
    private javax.swing.JLabel jLabelPeriodo4;
    private javax.swing.JLabel jLabelPeriodo5;
    private javax.swing.JLabel jLabelPontos2;
    private javax.swing.JLabel jLabelPontos3;
    private javax.swing.JLabel jLabelPontos4;
    private javax.swing.JLabel jLabelQtd3;
    private javax.swing.JLabel jLabelQtd4;
    private javax.swing.JLabel jLabelQtd5;
    private javax.swing.JLabel jLabelQtdPontos3;
    private javax.swing.JLabel jLabelQtdPontos4;
    private javax.swing.JLabel jLabelQtdPontos5;
    private javax.swing.JLabel jLabelTempo1;
    private javax.swing.JLabel jLabelTempo2;
    private javax.swing.JLabel jLabelTempo3;
    private javax.swing.JLabel jLabelTermino3;
    private javax.swing.JLabel jLabelTermino4;
    private javax.swing.JLabel jLabelTermino5;
    private javax.swing.JLabel jLabelTipo3;
    private javax.swing.JLabel jLabelTipo4;
    private javax.swing.JLabel jLabelTipo5;
    private javax.swing.JLabel jLabelTipoPreenchido3;
    private javax.swing.JLabel jLabelTipoPreenchido4;
    private javax.swing.JLabel jLabelTipoPreenchido5;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPanel jPanelGrupo1;
    private javax.swing.JPanel jPanelGrupo2;
    private javax.swing.JPanel jPanelGrupo3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables
}
