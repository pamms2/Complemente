package view;

import controller.AlunoController;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Aluno;
import view.PerfilAlunoGUI;

public class LoginGUI extends javax.swing.JFrame {

    private AlunoController alunoController = new AlunoController();
    private Aluno a = new Aluno();
    private static LoginGUI loginUnic;
    
    public static LoginGUI geraLoginGUI() {
        if(loginUnic == null) {
            loginUnic = new LoginGUI();
        }
        return loginUnic;
    }
    
    public LoginGUI() {
        initComponents();
        this.setExtendedState(LoginGUI.MAXIMIZED_BOTH);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelTitulo = new javax.swing.JLabel();
        jLabelRA = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldRA1 = new javax.swing.JTextField();
        jButtonCancelar = new javax.swing.JButton();
        jButtonLogin = new javax.swing.JButton();
        jButtonCriar = new javax.swing.JButton();
        jPasswordSenha = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTitulo.setText("COMPLEMENTE");

        jLabelRA.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelRA.setText("RA:");

        jLabel1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel1.setText("Senha:");

        jTextFieldRA1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldRA1ActionPerformed(evt);
            }
        });

        jButtonCancelar.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        jButtonLogin.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButtonLogin.setText("Entrar");
        jButtonLogin.setMaximumSize(new java.awt.Dimension(77, 21));
        jButtonLogin.setMinimumSize(new java.awt.Dimension(77, 21));
        jButtonLogin.setPreferredSize(new java.awt.Dimension(77, 21));
        jButtonLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLoginActionPerformed(evt);
            }
        });

        jButtonCriar.setText("Criar nova conta");
        jButtonCriar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCriarActionPerformed(evt);
            }
        });

        jPasswordSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordSenhaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(200, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jButtonLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButtonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jPasswordSenha))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabelRA)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTextFieldRA1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabelTitulo))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jButtonCriar, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(200, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addComponent(jLabelTitulo)
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldRA1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelRA))
                .addGap(56, 56, 56)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jPasswordSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonCancelar)
                    .addComponent(jButtonLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addComponent(jButtonCriar)
                .addContainerGap(65, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldRA1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldRA1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldRA1ActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        sair();
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jButtonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLoginActionPerformed
        entrar();
    }//GEN-LAST:event_jButtonLoginActionPerformed

    private void jButtonCriarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCriarActionPerformed
        abreCadastroAlunoGUI();
    }//GEN-LAST:event_jButtonCriarActionPerformed

    private void jPasswordSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordSenhaActionPerformed

    }//GEN-LAST:event_jPasswordSenhaActionPerformed

    //método vinculado ao botão de entrar, que verifica se o aluno apresenta as credenciais corretas
    public void entrar() { 
        String ra = jTextFieldRA1.getText().trim();
        String senha = jPasswordSenha.getText().trim();

        if (ra.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(
                null,
                "RA deve ser um número inteiro!",
                "Erro de Dados",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try {
            AlunoController alunoController = new AlunoController();
            Aluno aluno = alunoController.autenticar(ra, senha);

            if (aluno != null) {
                JOptionPane.showMessageDialog(
                        null,
                        "Login realizado com sucesso!\nBem-vindo(a), " + aluno.getNome(),
                        "Autenticação",
                        JOptionPane.INFORMATION_MESSAGE
                );   
                jTextFieldRA1.setText("");
                jPasswordSenha.setText("");
                PerfilAlunoGUI.geraPerfilAlunoGUI(aluno).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(
                        null,
                        "RA ou senha incorretos.",
                        "Erro de Dados",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados: " + ex.getMessage());
        }
    }

    
    public void abreCadastroAlunoGUI() {
        CadastrarAlunoGUI.geraCadastrarAlunoGUI().setVisible(true);
        dispose();
    }            
           
    public void sair() {
        dispose();
        System.exit(0);
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                LoginGUI.geraLoginGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonCriar;
    private javax.swing.JButton jButtonLogin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelRA;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPasswordField jPasswordSenha;
    private javax.swing.JTextField jTextFieldRA1;
    // End of variables declaration//GEN-END:variables
}
