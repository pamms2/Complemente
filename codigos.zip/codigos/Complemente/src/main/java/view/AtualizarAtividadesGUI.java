package view;

import model.Atividade;
import model.Aluno;
import controller.AtividadeController;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AtualizarAtividadesGUI extends javax.swing.JFrame {
    
    private static AtualizarAtividadesGUI atualizarAtividadesUnic;
    private static int raAluno;
    private static Aluno alunoAtual;
    
    public static AtualizarAtividadesGUI geraAtualizarAtividadesGUI(Aluno aluno) {
        if(atualizarAtividadesUnic == null) {
            atualizarAtividadesUnic = new AtualizarAtividadesGUI(aluno);
        }
        
        alunoAtual = aluno;
        return atualizarAtividadesUnic;
    }
    
    private AtualizarAtividadesGUI(Aluno a) {
        alunoAtual = a;
        raAluno = a.getRA();
        initComponents();
        carregarAtividades(); 
        configurarBotaoEditar();
    }
    
    private void configurarBotaoEditar() {
        jButtonEditar = new javax.swing.JButton();
        jButtonEditar.setFont(new java.awt.Font("Arial", 0, 12)); 
        jButtonEditar.setText("Editar Atividade");
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
    }



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelTitulo = new javax.swing.JLabel();
        jScrollPaneLista = new javax.swing.JScrollPane();
        jTableAtividades = new javax.swing.JTable();
        jButtonSair = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jButtonConsultar = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonCadastro = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setText("Atividades");

        jTableAtividades.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTableAtividades.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Tipo", "Descrição", "Início", "Fim", "Duração", "Pontos", "Grupos"
            }
        ));
        jScrollPaneLista.setViewportView(jTableAtividades);

        jButtonSair.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });

        jButtonExcluir.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButtonExcluir.setText("Excluir Atividade");
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });

        jButtonConsultar.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButtonConsultar.setText("Consultar Atividade");
        jButtonConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConsultarActionPerformed(evt);
            }
        });

        jButtonEditar.setText("Editar Atividade");
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });

        jButtonCadastro.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButtonCadastro.setText("Cadastrar Atividade");
        jButtonCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCadastroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButtonSair)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPaneLista)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButtonCadastro)
                                .addGap(12, 12, 12)
                                .addComponent(jButtonEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButtonExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButtonConsultar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addContainerGap(60, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(291, Short.MAX_VALUE)
                .addComponent(jLabelTitulo)
                .addContainerGap(292, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabelTitulo)
                .addGap(18, 18, 18)
                .addComponent(jScrollPaneLista, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonConsultar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonCadastro, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
                    .addComponent(jButtonEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jButtonSair)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        sair();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConsultarActionPerformed
        consultarAtividades();
    }//GEN-LAST:event_jButtonConsultarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
        excluirAtividades();
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
        int linha = jTableAtividades.getSelectedRow();
        if (linha >= 0) {
            int id = (int) jTableAtividades.getValueAt(linha, 0); // coluna 0 = ID
            AtividadeController controller = new AtividadeController();
            List<Atividade> lista = controller.buscarTodasAtividades(raAluno);

            for (Atividade a : lista) {
                if (a.getId() == id) {
                    AlterarAtividadeGUI.geraAlterarAtividadeGUI(a, alunoAtual);
                    dispose();
                    break;
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma atividade para editar.");
        }
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCadastroActionPerformed
        abreCadastroAtividadeGUI();
    }//GEN-LAST:event_jButtonCadastroActionPerformed

    public void abreCadastroAtividadeGUI() {
        CadastroAtividadeGUI.geraCadastroAtividadeGUI(alunoAtual).setVisible(true);
        dispose();
    }
    
    public void excluirAtividades() {
        int linhaSelecionada = jTableAtividades.getSelectedRow();

        if (linhaSelecionada == -1) {
            javax.swing.JOptionPane.showMessageDialog(null, "Selecione uma atividade para excluir.");
            return;
        }

        int id = (int) jTableAtividades.getValueAt(linhaSelecionada, 0);
        int confirm = javax.swing.JOptionPane.showConfirmDialog(null, "Deseja realmente excluir esta atividade?", "Confirmação", javax.swing.JOptionPane.YES_NO_OPTION);

        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            AtividadeController controller = new AtividadeController();
            controller.excluirAtividade(id);
            carregarAtividades();
            javax.swing.JOptionPane.showMessageDialog(null, "Atividade excluída com sucesso!");
        }
    }

    public void sair() {
        int resp = JOptionPane.showConfirmDialog(
            null,
            "Deseja realmente cancelar?",
            "Saída",
            JOptionPane.YES_NO_OPTION
        );
        if(resp == JOptionPane.YES_OPTION){
            PerfilAlunoGUI.geraPerfilAlunoGUI(alunoAtual).setVisible(true);
            dispose();
        }
    }
    
    public void consultarAtividades() {
        int linhaSelecionada = jTableAtividades.getSelectedRow();

        if (linhaSelecionada == -1) {
            javax.swing.JOptionPane.showMessageDialog(null, "Selecione uma atividade para consultar.");
            return;
        }
        int id = (int) jTableAtividades.getValueAt(linhaSelecionada, 0);

        String tipo = jTableAtividades.getValueAt(linhaSelecionada, 1).toString();
        String descricao = jTableAtividades.getValueAt(linhaSelecionada, 2).toString();
        String inicio = jTableAtividades.getValueAt(linhaSelecionada, 3).toString();
        String fim = jTableAtividades.getValueAt(linhaSelecionada, 4).toString();
        String duracao = jTableAtividades.getValueAt(linhaSelecionada, 5).toString();
        String pontos = jTableAtividades.getValueAt(linhaSelecionada, 6).toString();
        String grupo = jTableAtividades.getValueAt(linhaSelecionada, 7).toString();

        String mensagem = String.format(
            "ID: %d\nTipo: %s\nDescrição: %s\nInício: %s\nFim: %s\nDuração: %s\nPontos: %s\nGrupo: %s",
            id, tipo, descricao, inicio, fim, duracao, pontos, grupo
        );

        javax.swing.JOptionPane.showMessageDialog(null, mensagem, "Consulta de Atividade", javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }

    public void carregarAtividades() {
        AtividadeController ativController = new AtividadeController();
        List<Atividade> lista = ativController.buscarTodasAtividades(raAluno);
        
        DefaultTableModel model = (DefaultTableModel) jTableAtividades.getModel();
        model.setRowCount(0); 

        for (Atividade a : lista) {
            model.addRow(new Object[]{
                a.getId(),
                a.getTipo(),
                a.getCarac().getDescricao(),
                formatarData(a.getCarac().getInicio()),
                formatarData(a.getCarac().getFim()),
                a.getCarac().getDuracao() + " " + a.getCarac().getUnidade(),
                a.getPontos(),
                a.getGrupo()
            });
        }
    }
    
    private String formatarData(Date data) {
        if (data == null) return "";
        return new SimpleDateFormat("dd/MM/yyyy").format(data);
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCadastro;
    private javax.swing.JButton jButtonConsultar;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JScrollPane jScrollPaneLista;
    private javax.swing.JTable jTableAtividades;
    // End of variables declaration//GEN-END:variables
}
