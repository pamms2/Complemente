package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import model.Atividade;
import model.Caracteristica;

public class AtividadeController {

    public void adicionarAtividade(Atividade atividade, int ra) throws SQLException {
        String sql = "INSERT INTO atividade (tipo, descricao, inicio, fim, duracao, unidade, pontos, grupo, ra) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";


        try (Connection con = DAO.getConexao();
            PreparedStatement ps = con.prepareStatement(sql)) {
            
            Date dataInicio = new Date(atividade.getCarac().getInicio().getTime());
            Date dataFim = new Date(atividade.getCarac().getFim().getTime());

            ps.setString(1, atividade.getTipo());
            ps.setString(2, atividade.getCarac().getDescricao());
            ps.setDate(3, dataInicio);
            ps.setDate(4, dataFim);
            ps.setInt(5, atividade.getCarac().getDuracao());
            ps.setString(6, atividade.getCarac().getUnidade());
            ps.setInt(7, atividade.getPontos());
            ps.setInt(8, atividade.getGrupo());
            ps.setInt(9, ra);

            ps.executeUpdate();

        } 
    }

    public List<Atividade> consultarAtividadesPorRA(int ra) {
        List<Atividade> atividades = new ArrayList<>();
        String sql = "SELECT * FROM atividade WHERE ra = ?";

        try (Connection con = DAO.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ra);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Atividade atividade = new Atividade();
                    Caracteristica carac = new Caracteristica();

                    atividade.setId(rs.getInt("id"));
                    atividade.setTipo(rs.getString("tipo"));
                    atividade.setPontos(rs.getInt("pontos"));
                    atividade.setGrupo(rs.getInt("grupo"));

                    carac.setDescricao(rs.getString("descricao"));
                    carac.setInicio(rs.getDate("inicio"));
                    carac.setFim(rs.getDate("fim"));
                    carac.setDuracao(rs.getInt("duracao"));
                    carac.setUnidade(rs.getString("unidade"));

                    atividade.setCarac(carac);

                    atividades.add(atividade);
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao consultar atividades:");
            e.printStackTrace();
        }

        return atividades;
    }

    public void excluirAtividade(int id) {
        String sql = "DELETE FROM atividade WHERE id = ?";

        try (Connection con = DAO.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Atividade excluída com sucesso!");
            } else {
                System.out.println("Atividade não encontrada.");
            }

        } catch (SQLException e) {
            System.err.println("Erro ao excluir atividade:");
            e.printStackTrace();
        }
    }

    public void atualizarAtividade(Atividade atividade) {
        String sql = "UPDATE atividade SET tipo = ?, pontos = ?, descricao = ?, inicio = ?, fim = ?, duracao = ?, unidade = ?, grupo = ? WHERE id = ?";


        try (Connection con = DAO.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, atividade.getTipo());
            ps.setInt(2, atividade.getPontos());
            ps.setString(3, atividade.getCarac().getDescricao());
            ps.setDate(4, new java.sql.Date(atividade.getCarac().getInicio().getTime()));
            ps.setDate(5, new java.sql.Date(atividade.getCarac().getFim().getTime()));
            ps.setInt(6, atividade.getCarac().getDuracao());
            ps.setString(7, atividade.getCarac().getUnidade());
            ps.setInt(8, atividade.getGrupo());
            ps.setInt(9, atividade.getId());

            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Atividade atualizada com sucesso!");
            } else {
                System.out.println("ID da atividade inválido. Nenhuma atualização feita.");
            }

        } catch (SQLException e) {
            System.err.println("Erro ao atualizar atividade:");
            e.printStackTrace();
        }
    }
    
    public List<Atividade> buscarTodasAtividades(int ra) {
        List<Atividade> lista = new ArrayList<>();

        String sql = "SELECT * FROM atividade WHERE ra = ?";

        try (Connection con = DAO.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ra);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Atividade atividade = new Atividade();

                atividade.setId(rs.getInt("id"));
                atividade.setTipo(rs.getString("tipo"));
                atividade.setPontos(rs.getInt("pontos"));
                atividade.setGrupo(rs.getInt("grupo"));

                Caracteristica carac = new Caracteristica();
                carac.setDescricao(rs.getString("descricao"));
                carac.setInicio(rs.getDate("inicio"));
                carac.setFim(rs.getDate("fim"));
                carac.setDuracao(rs.getInt("duracao"));
                carac.setUnidade(rs.getString("unidade"));

                atividade.setCarac(carac);

                lista.add(atividade);
            }

        } catch (SQLException e) {
            System.err.println("Erro ao buscar atividades: " + e.getMessage());
        }

        return lista;
    }

}
