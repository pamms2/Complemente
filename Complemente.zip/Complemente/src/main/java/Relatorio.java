

import model.Aluno;
import model.Atividade;
import model.Caracteristica;
import org.apache.poi.xwpf.usermodel.*;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class Relatorio {

    private static void substituirTexto(XWPFParagraph paragrafo, Map<String, String> substituicoes) {
        StringBuilder textoCompleto = new StringBuilder();
        List<XWPFRun> runs = paragrafo.getRuns();

        for (XWPFRun run : runs) {
            if (run.getText(0) != null) {
                textoCompleto.append(run.getText(0));
            }
        }

        String textoFinal = textoCompleto.toString();

        for (Map.Entry<String, String> entry : substituicoes.entrySet()) {
            textoFinal = textoFinal.replace(entry.getKey(), entry.getValue());
        }

        for (int i = runs.size() - 1; i >= 0; i--) {
            paragrafo.removeRun(i);
        }

        XWPFRun novoRun = paragrafo.createRun();
        novoRun.setText(textoFinal);
    }

    private static void substituirTextoNoDocumento(XWPFDocument doc, Map<String, String> substituicoes) {
        for (XWPFParagraph p : doc.getParagraphs()) {
            substituirTexto(p, substituicoes);
        }
        for (XWPFTable tabela : doc.getTables()) {
            substituirTextoNoDocumento(tabela, substituicoes);
        }
    }

    private static void substituirTextoNoDocumento(XWPFTable tabela, Map<String, String> substituicoes) {
        for (XWPFTableRow linha : tabela.getRows()) {
            for (XWPFTableCell celula : linha.getTableCells()) {
                for (XWPFParagraph p : celula.getParagraphs()) {
                    substituirTexto(p, substituicoes);
                }
            }
        }
    }

    private static String formatarData(Date data) {
        if (data == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(data);
    }

    private static Aluno criarAlunoExemplo() {
        List<Atividade> listaAtividades = new ArrayList<>();
        Aluno aluno = new Aluno(2564254, "hdamds43", "Pamela Berti Braz", "pbraz@alunos.utfpr.edu.br", "Engenharia de Software", 81, listaAtividades);

        Calendar cal = Calendar.getInstance();

        cal.set(2004, Calendar.NOVEMBER, 2);
        Date dataInicio = cal.getTime();

        cal.set(2005, Calendar.DECEMBER, 5);
        Date dataFim = cal.getTime();

        Caracteristica carac1 = new Caracteristica("Participação em evento", dataFim, 15, "meses", dataInicio);

        cal.set(2025, Calendar.JANUARY, 15);
        dataInicio = cal.getTime();

        cal.set(2025, Calendar.APRIL, 15);
        dataFim = cal.getTime();

        Caracteristica carac2 = new Caracteristica("Curso online", dataFim, 3, "meses", dataInicio);

        aluno.adicionarAtividade(new Atividade(1, "Palestra", 5, carac1, 0));
        aluno.adicionarAtividade(new Atividade(2, "Curso", 15, carac2, 1));

        return aluno;
    }

    public static XWPFTable clonarTabela(XWPFDocument doc, XWPFTable tabelaOriginal) throws XmlException {
        String xml = tabelaOriginal.getCTTbl().xmlText();
        XWPFTable novaTabela = doc.createTable();
        novaTabela.getCTTbl().set(XmlObject.Factory.parse(xml));
        novaTabela.removeRow(0); // Remove a linha inicial em branco que é criada automaticamente
        return novaTabela;
    }


    public static void main(String[] args) throws Exception {
        String caminhoModelo = "C:\\Users\\pambe\\Downloads\\Relatorio-Pontuacao.docx";
        String caminhoSaida = "C:\\Users\\pambe\\OneDrive\\Área de Trabalho\\Relatorio-Preenchido.docx";

        Aluno aluno = criarAlunoExemplo();

        FileInputStream fis = new FileInputStream(caminhoModelo);
        XWPFDocument doc = new XWPFDocument(fis);

        // Substituições de dados do aluno
        Map<String, String> substituicoes = new HashMap<>();
        substituicoes.put("{{NOME}}", aluno.getNome());
        substituicoes.put("{{RA}}", String.valueOf(aluno.getRA()));
        substituicoes.put("{{CURSO}}", aluno.getCurso());
        substituicoes.put("{{COD_CURSO}}", String.valueOf(aluno.getCodCurso()));
        substituicoes.put("{{EMAIL}}", aluno.getEmail());

        substituirTextoNoDocumento(doc, substituicoes);

        // Seleciona a tabela modelo (ex: a segunda do documento)
        XWPFTable tabelaModelo = doc.getTables().get(1);

        // Para cada atividade, clona e insere nova tabela com os dados preenchidos
        List<Atividade> atividades = aluno.getAtividades();
        for(int i = 0; i < atividades.size(); i++) {
            if (i == 0) {
                Atividade atv = atividades.get(0);

                Map<String, String> subAtividade = new HashMap<>();
                subAtividade.put("{{TIPO}}", atv.getTipo());
                subAtividade.put("{{GRUPO}}", String.valueOf(atv.getGrupo()));
                subAtividade.put("{{ID}}", Integer.toString(atv.getId()));
                subAtividade.put("{{DESCRICAO}}", atv.getCarac().getDescricao());
                subAtividade.put("{{INICIO}}", formatarData(atv.getCarac().getInicio()));
                subAtividade.put("{{TERMINO}}", formatarData(atv.getCarac().getFim()));
                subAtividade.put("{{PONTOS}}", String.valueOf(atv.getPontos()));
                subAtividade.put("{{DURACAO}}", atv.getCarac().getDuracao() + " " + atv.getCarac().getUnidade());
                
                substituirTextoNoDocumento(tabelaModelo, subAtividade);
            } else if(i != atividades.size() - 1)  {
                Atividade atv = atividades.get(i);

                Map<String, String> subAtividade = new HashMap<>();
                subAtividade.put("{{TIPO}}", atv.getTipo());
                subAtividade.put("{{GRUPO}}", String.valueOf(atv.getGrupo()));
                subAtividade.put("{{ID}}", Integer.toString(atv.getId()));
                subAtividade.put("{{DESCRICAO}}", atv.getCarac().getDescricao());
                subAtividade.put("{{INICIO}}", formatarData(atv.getCarac().getInicio()));
                subAtividade.put("{{TERMINO}}", formatarData(atv.getCarac().getFim()));
                subAtividade.put("{{PONTOS}}", String.valueOf(atv.getPontos()));
                subAtividade.put("{{DURACAO}}", atv.getCarac().getDuracao() + " " + atv.getCarac().getUnidade());
                
                XWPFTable tabelaClonada = clonarTabela(doc, tabelaModelo);
                int pos = doc.getBodyElements().indexOf(tabelaModelo);
                doc.setTable(pos + i, tabelaClonada);
                substituirTextoNoDocumento(tabelaClonada, subAtividade);
            } else {
                Atividade atv = atividades.get(i);
                XWPFTable tabelaClonada = clonarTabela(doc, tabelaModelo);
                int pos = doc.getBodyElements().indexOf(tabelaModelo);
                doc.setTable(pos + i, tabelaClonada);

                Map<String, String> subAtividade = new HashMap<>();
                subAtividade.put("{{TIPO}}", atv.getTipo());
                subAtividade.put("{{GRUPO}}", String.valueOf(atv.getGrupo()));
                subAtividade.put("{{ID}}", String.valueOf(atv.getId()));
                subAtividade.put("{{DESCRICAO}}", atv.getCarac().getDescricao());
                subAtividade.put("{{INICIO}}", formatarData(atv.getCarac().getInicio()));
                subAtividade.put("{{TERMINO}}", formatarData(atv.getCarac().getFim()));
                subAtividade.put("{{PONTOS}}", String.valueOf(atv.getPontos()));
                subAtividade.put("{{DURACAO}}", atv.getCarac().getDuracao() + " " + atv.getCarac().getUnidade());
                
                substituirTextoNoDocumento(tabelaClonada, subAtividade);
            }          
        }

        FileOutputStream fos = new FileOutputStream(caminhoSaida);
        doc.write(fos);
        fos.close();
        doc.close();
        fis.close();

        System.out.println("Documento gerado com sucesso em: " + caminhoSaida);
    }
}
