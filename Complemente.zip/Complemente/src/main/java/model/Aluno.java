package model;

import java.util.ArrayList;
import java.util.List;

public class Aluno {
    private int ra;                         //RA do aluno
    private String senha;                   //senha do aluno
    private String nome;                    //Nome completo do aluno
    private String email;                   //E-mail vinculado ao aluno
    private String curso;                   //Curso que o aluno está cursando
    private int codCurso;                   //Código do curso que o aluno está cursando
    private List<Atividade> atividades;     //lista de atividades que o aluno apresenta
    private TotalAtividade totalAtividade;  //Soma de pontos das atividades
    
    //métodos construtores de aluno
    public Aluno() {
        ra = 0;
        senha = "";
        nome = "";
        email = "";
        curso = "";
        codCurso = 0;
        atividades = new ArrayList<>();
        totalAtividade = new TotalAtividade();
    }
    
    public Aluno(int ra, String senha, String nome, String email, String curso, int codCurso, List<Atividade> atividades, TotalAtividade totalAtividade) {
        this.ra = ra;
        this.senha = senha;
        this.nome = nome;
        this.email = email;
        this.curso = curso;
        this.codCurso = codCurso;
        this.atividades = new ArrayList<>();
        this.totalAtividade = totalAtividade;
    }
    
    public Aluno(int ra, String senha, String nome, String email, String curso, int codCurso) {
        this.ra = ra;
        this.senha = senha;
        this.nome = nome;
        this.email = email;
        this.curso = curso;
        this.codCurso = codCurso;
        this.atividades = new ArrayList<>(); // inicializa aqui
    }

    //getters
    public int getRA() {
        return ra;
    }
    
    public String getSenha() {
        return senha;
    }
    
    public String getNome() {
        return nome;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getCurso() {
        return curso;
    }
    
    public int getCodCurso() {
        return codCurso;
    }
    
    public TotalAtividade getTotalAtividade() {
        return totalAtividade;
    }
    
    //setters
    public void setRA(int ra) {
       this.ra = ra;
    }
    
    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public void setCurso(String curso) {
        this.curso = curso;
    }
    
    public void setCodCurso(int codCurso) {
        this.codCurso = codCurso;
    }
    
    public List<Atividade> getAtividades() {
        return atividades;
    }

    public void setAtividades(List<Atividade> atividades) {
        this.atividades = atividades;
    }
    
    public void setTotalAtividade(TotalAtividade totalAtividade) {
        this.totalAtividade = totalAtividade;
    }

    public void adicionarAtividade(Atividade atividade) {
        this.atividades.add(atividade);
    }
    
}