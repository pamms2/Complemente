package model;

import java.util.ArrayList;
import java.util.List;

public class Aluno {
    private int ra;
    private String senha;
    private String nome;
    private String email;
    private String curso;
    private int codCurso;
    private List<Atividade> atividades;
    
    public Aluno() {
        ra = 0;
        senha = "";
        nome = "";
        email = "";
        curso = "";
        codCurso = 0;
        atividades = new ArrayList<>();
    }
    
    public Aluno(int ra, String senha, String nome, String email, String curso, int codCurso, List<Atividade> atividades) {
        this.ra = ra;
        this.senha = senha;
        this.nome = nome;
        this.email = email;
        this.curso = curso;
        this.codCurso = codCurso;
        this.atividades = new ArrayList<>();
    }
    
    public Aluno(int ra, String senha, String nome, String email, String curso, int codCurso) {
    this.ra = ra;
    this.senha = senha;
    this.nome = nome;
    this.email = email;
    this.curso = curso;
    this.codCurso = codCurso;
    this.atividades = new ArrayList<>(); // inicializa aqui
}

    
    public int getRA() {
        return ra;
    }
    
    public String getSenha() {
        return senha;
    }
    
    public String getNome() {
        return nome;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getCurso() {
        return curso;
    }
    
    public int getCodCurso() {
        return codCurso;
    }
    
    public void setRA(int ra) {
       this.ra = ra;
    }
    
    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public void setCurso(String curso) {
        this.curso = curso;
    }
    
    public void setCodCurso(int codCurso) {
        this.codCurso = codCurso;
    }
    
    public List<Atividade> getAtividades() {
        return atividades;
    }

    public void setAtividades(List<Atividade> atividades) {
        this.atividades = atividades;
    }

    public void adicionarAtividade(Atividade atividade) {
        this.atividades.add(atividade);
    }
    
}