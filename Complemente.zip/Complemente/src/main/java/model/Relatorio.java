package model;

public interface Relatorio {
    public void gerarRelatorio();
}
