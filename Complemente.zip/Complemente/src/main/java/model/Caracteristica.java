package model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Caracteristica {
    private String descricao;
    private Date fim;
    private int duracao;
    private String unidade;
    private Date inicio;
    
    public Caracteristica(){
        descricao = "";
        fim = null;
        duracao = 0;
        unidade = "";
        inicio = null;
    }
    
    public Caracteristica(String descricao, Date fim, int duracao, String unidade, Date inicio){
        this.descricao = descricao;
        this.fim = fim;
        this.duracao = duracao; 
        this.unidade = unidade;
        this.inicio = inicio;
    }
    
    public String getDescricao(){
        return descricao;
    }
    
    public Date getFim(){
        return fim;
    }
    
    public int getDuracao(){
        return duracao;
    }
    
    public String getUnidade(){
        return unidade;
    }
    
    public Date getInicio(){
        return inicio;
    }    
    
    public void setDescricao(String descricao){
        this.descricao = descricao;
    }
    
    public void setFim(Date fim){
        this.fim = fim;
    }
    
    public void setDuracao(int duracao){
        this.duracao = duracao;
    }
    
    public void setUnidade(String unidade){
        this.unidade = unidade;
    }
    
    public void setInicio(Date inicio){
        this.inicio = inicio;
    }
}