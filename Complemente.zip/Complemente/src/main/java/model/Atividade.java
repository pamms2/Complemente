package model;

public class Atividade{
    private int id;                 //ID da Atividade
    private String tipo;            //Tipo da Atividade
    private int pontos;             //Quantidade de pontos que a atividade vale
    private Caracteristica carac;   //Características gerais da atividade
    private int grupo;              //Em qual grupo a atividade se enquadra
    
    //construtores de Atividade
    public Atividade(){
        id = 0;
        tipo = "";
        pontos = 0;
        carac = new Caracteristica();
        grupo = 0;
    }
    
    public Atividade(int id, String tipo, int pontos, Caracteristica carac, int grupo){
        this.id = id;
        this.tipo = tipo;
        this.pontos = pontos;
        this.carac = carac;
        this.grupo = grupo;
    }
    
    //getters
    public int getId(){
        return id;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public int getPontos(){
        return pontos;
    }
    
    public Caracteristica getCarac(){
        return carac;
    }
    
    public int getGrupo() {
        return grupo;
    }
    
    //setters
    public void setId(int id){
        this.id = id;
    }
    
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    
    public void setPontos(int pontos){
        this.pontos = pontos;
    }
    
    public void setCarac(Caracteristica carac){
        this.carac = carac;
    }
    
    public void setGrupo(int grupo) {
        this.grupo = grupo;
    }
}
