package model;

import model.Atividade;

public class TotalAtividade {
    private int somaPontos;
    private Atividade ativ;
    
    public TotalAtividade(){
        somaPontos = 0;
        ativ = new Atividade();
    }
    
    public TotalAtividade(int somaPontos, Atividade ativ){
        this.somaPontos = somaPontos;
        this.ativ = ativ;
    }
    
    public void calcularPontos() {
    }

    public void definirLimites() {
    }
    
    public int getSomaPontos(){
        return somaPontos;
    }
    
    public Atividade getAtiv(){
        return ativ;
    }
    
    public void setSomaPontos(int somaPontos){
        this.somaPontos = somaPontos;
    }
    
    public void setAtiv(Atividade ativ){
        this.ativ = ativ;
    }
}
