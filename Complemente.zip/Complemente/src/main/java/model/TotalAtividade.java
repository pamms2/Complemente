package model;

import java.util.List;
import model.Atividade;

public class TotalAtividade {
    private int somaPontosTotal;
    private int somaG1;
    private int somaG2;
    private int somaG3;
    private int ra;
    
    public TotalAtividade(){
        somaPontosTotal = 0;
        somaG1 = 0;
        somaG2 = 0;
        somaG3 = 0;
    }
    
    public TotalAtividade(int somaPontosTotal, int somaG1, int somaG2, int somaG3){
        this.somaPontosTotal = somaPontosTotal;
        this.somaG1 = somaG1;
        this.somaG2 = somaG2;
        this.somaG3 = somaG3;
    }
    
    public void calcularPontos(List<Atividade> atividadesSelecionadas) {
        
        // zera tudo antes de somar
        somaG1 = 0;
        somaG2 = 0;
        somaG3 = 0;
        somaPontosTotal = 0;

        for (Atividade atividade : atividadesSelecionadas) {
            int pontos = atividade.getPontos();

            switch (atividade.getGrupo()) {
                case 1:
                    somaG1 += pontos;
                    break;
                    
                case 2:
                    somaG2 += pontos;
                    break;
                    
                case 3:
                    somaG3 += pontos;
                    break;
            }

            somaPontosTotal += pontos;
        }
    }
    
    public String verificarErrosDeLimites() {
        StringBuilder erros = new StringBuilder();

        // Grupo 1
        if (somaG1 < 10) {
            erros.append("Grupo 1: mínimo de 10 pontos não atingido (faltam ")
                 .append(10 - somaG1).append(" ponto(s)).\n");
        } else if (somaG1 > 40) {
            erros.append("Grupo 1: máximo de 40 pontos excedido (excedeu em ")
                 .append(somaG1 - 40).append(" ponto(s)).\n");
        }

        // Grupo 2
        if (somaG2 < 10) {
            erros.append("Grupo 2: mínimo de 10 pontos não atingido (faltam ")
                 .append(10 - somaG2).append(" ponto(s)).\n");
        } else if (somaG2 > 30) {
            erros.append("Grupo 2: máximo de 30 pontos excedido (excedeu em ")
                 .append(somaG2 - 30).append(" ponto(s)).\n");
        }

        // Grupo 3
        if (somaG3 < 10) {
            erros.append("Grupo 3: mínimo de 10 pontos não atingido (faltam ")
                 .append(10 - somaG3).append(" ponto(s)).\n");
        } else if (somaG3 > 40) {
            erros.append("Grupo 3: máximo de 40 pontos excedido (excedeu em ")
                 .append(somaG3 - 40).append(" ponto(s)).\n");
        }

        // Total
        if (somaPontosTotal < 60) {
            erros.append("Pontuação total: mínimo de 60 pontos não atingido (faltam ")
                 .append(60 - somaPontosTotal).append(" ponto(s)).\n");
        }

        return erros.toString();
    }    
    
    
    //getters
    public int getSomaPontosTotal(){
        return somaPontosTotal;
    }
    
    public int getSomaG1() {
        return somaG1;
    }
    
    public int getSomaG2() {
        return somaG2;
    }
    
    public int getSomaG3() {
        return somaG3;
    }
    
    public int getRa() {
        return ra;
    }
    
    //setters
    public void setSomaPontosTotal (int somaPontosTotal){
        this.somaPontosTotal = somaPontosTotal;
    }
    
    public void setSomaG1(int somaG1) {
        this.somaG1 = somaG1;
    }
    
    public void setSomaG2(int somaG2) {
        this.somaG2 = somaG2;
    }
    
    public void setSomaG3(int somaG3) {
        this.somaG3 = somaG3;
    }
    
    public void setRa(int ra) {
        this.ra = ra;
    }
}
