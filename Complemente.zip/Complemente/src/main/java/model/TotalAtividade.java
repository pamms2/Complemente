package model;

import model.Atividade;

public class TotalAtividade {
    private int somaPontosTotal;
    private int somaG1;
    private int somaG2;
    private int somaG3;
    private Atividade ativ;
    
    public TotalAtividade(){
        somaPontosTotal = 0;
        ativ = new Atividade();
        somaG1 = 0;
        somaG2 = 0;
        somaG3 = 0;
    }
    
    public TotalAtividade(int somaPontosTotal, Atividade ativ, int somaG1, int somaG2, int somaG3){
        this.somaPontosTotal = somaPontosTotal;
        this.ativ = ativ;
        this.somaG1 = somaG1;
        this.somaG2 = somaG2;
        this.somaG3 = somaG3;
    }
    
    public void calcularPontos() {
    }

    public void definirLimites() {
    }
    
    public int getSomaPontosTotal(){
        return somaPontosTotal;
    }
    
    public Atividade getAtiv(){
        return ativ;
    }
    
    public int getSomaG1() {
        return somaG1;
    }
    
    public int getSomaG2() {
        return somaG2;
    }
    
    public int getSomaG3() {
        return somaG3;
    }
    
    public void setSomaPontosTotal (int somaPontosTotal){
        this.somaPontosTotal = somaPontosTotal;
    }
    
    public void setAtiv(Atividade ativ){
        this.ativ = ativ;
    }
    
    public void setSomaG1(int somaG1) {
        this.somaG1 = somaG1;
    }
    
    public void setSomaG2(int somaG2) {
        this.somaG2 = somaG2;
    }
    
    public void setSomaG3(int somaG3) {
        this.somaG3 = somaG3;
    }
}
