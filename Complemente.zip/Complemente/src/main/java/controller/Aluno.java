package controller;

public class Aluno {
    private int ra;
    private String senha;
    private String nome;
    private String email;
    private String curso;
    private int codCurso;
    
    public Aluno(int ra, String senha, String nome, String email, String curso, int codCurso){
        this.ra = ra;
        this.senha = senha;
        this.nome = nome;
        this.email = email;
        this.curso = curso;
        this.codCurso = codCurso;
    }
    
    public int getRa(){
        return ra;
    }
    
    public String getSenha(){
        return senha;
    }
    
    public String getNome(){
        return nome;
    }
    
    public String getEmail(){
        return email;
    }
    
    public String getCurso(){
        return curso;
    }
    
    public int getCodCurso(){
        return codCurso;
    }
    
    public void setRa(int ra){
       this.ra = ra;
    }
    
    public void setSenha(String senha){
        this.senha = senha;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setEmail(String email){
        this.email = email;
    }
    
    public void setCurso(String curso){
        this.curso = curso;
    }
    
    public void setCodCurso(int codCurso){
        this.codCurso = codCurso;
    }
}