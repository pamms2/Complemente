package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Conexao {
    static Connection con = null;    
    static String url =  "jdbc:mysql://localhost:3306/complemente";
    static String driver = "com.mysql.cj.jdbc.Driver";
    static String user = "root";
    static String senha = "12345"; 
    static Statement st;
    
    public static Connection getConexao() {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, senha);
        } catch (ClassNotFoundException e) {
            System.err.println("Driver JDBC não encontrado: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Erro ao conectar com o banco: " + e.getMessage());
        }
        return null;
    }
}