package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Conexao {
    static Connection con = null;    
    static String url =  "jdbc:mysql://localhost:3306/complemente";
    static String driver = "com.mysql.cj.jdbc.Driver";
    static String user = "root";
    static String senha = "12345";
    static Statement st;
    
    public static void main(String[] args) {
        try { //carregar o driver
            System.out.println("Carregando o driver...");
            Class.forName(driver);
            System.out.println("Driver carregado com sucesso.");
        } catch(Exception e) {
            System.out.println(e);
        }    
        try { //conectar com o BD
            System.out.println("Conectando o BD...");
            con = DriverManager.getConnection(url, user, senha);
            System.out.println("BD conectado com sucesso.");
        } catch(Exception e) {
            System.out.println(e);
        } 
        
        ResultSet rs;
        String sql2 = "SELECT *FROM Aluno";
        try {
            con = DriverManager.getConnection(url, user, senha);
            st = con.createStatement();
            rs = st.executeQuery(sql2);
            while(rs.next()) {
                System.out.println("RA = "+rs.getInt(1));
                System.out.println("Nome = "+rs.getString(2));
                System.out.println("E-mail = "+rs.getString(3));
                System.out.println("Senha = "+rs.getString(4));
                System.out.println("Codigo Curso = "+rs.getInt(5));
                System.out.println("Curso = "+rs.getString(6));
            }
            st.close();
            rs.close();
            con.close();
        } catch(Exception e) {
            System.out.println(e);
        }
        
        String sql3 = "DELETE FROM Aluno WHERE ra = 2601435";
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, senha);
            System.out.println("Excluindo dados...");
            st = con.createStatement();
            st.executeUpdate(sql3);
            st.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}