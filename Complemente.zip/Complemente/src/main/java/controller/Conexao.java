package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Conexao {
    static Connection con = null;    
    static String url =  "jdbc:mysql://localhost:3306/complemente";
    static String driver = "com.mysql.cj.jdbc.Driver";
    static String user = "root";
    static String senha = "12345";
    static Statement st;
    
    public static Connection getConexao() {
        try { //carregar o driver
            Class.forName(driver);
        } catch(Exception e) {
            System.out.println(e);
        }    
        try { //conectar com o BD
            con = DriverManager.getConnection(url, user, senha);
        } catch(Exception e) {
            System.out.println(e);
        }   
        return con;
    }
}