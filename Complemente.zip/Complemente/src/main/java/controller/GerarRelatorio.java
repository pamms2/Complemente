package controller;


import model.Aluno;
import model.Atividade;
import model.Caracteristica;
import org.apache.poi.xwpf.usermodel.*;
import java.text.SimpleDateFormat;
import java.util.*;
import model.TotalAtividade;
import org.apache.xmlbeans.XmlCursor;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTbl;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;



public class GerarRelatorio {


    private static void substituirTexto(XWPFParagraph paragrafo, Map<String, String> substituicoes) {
        StringBuilder textoCompleto = new StringBuilder();
        List<XWPFRun> runs = paragrafo.getRuns();

        for (XWPFRun run : runs) {
            if (run.getText(0) != null) {
                textoCompleto.append(run.getText(0));
            }
        }

        String textoFinal = textoCompleto.toString();

        for (Map.Entry<String, String> entry : substituicoes.entrySet()) {
            textoFinal = textoFinal.replace(entry.getKey(), entry.getValue());
        }

        for (int i = runs.size() - 1; i >= 0; i--) {
            paragrafo.removeRun(i);
        }

        XWPFRun novoRun = paragrafo.createRun();
        novoRun.setText(textoFinal);
    }

    private static void substituirTextoNoDocumento(XWPFDocument doc, Map<String, String> substituicoes) {
        for (XWPFParagraph p : doc.getParagraphs()) {
            substituirTexto(p, substituicoes);
        }
        for (XWPFTable tabela : doc.getTables()) {
            substituirTextoNoDocumento(tabela, substituicoes);
        }
    }

    private static void substituirTextoNoDocumento(XWPFTable tabela, Map<String, String> substituicoes) {
        for (XWPFTableRow linha : tabela.getRows()) {
            for (XWPFTableCell celula : linha.getTableCells()) {
                for (XWPFParagraph p : celula.getParagraphs()) {
                    substituirTexto(p, substituicoes);
                }
            }
        }
    }

    private static String formatarData(Date data) {
        if (data == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(data);
    }
    
    private static XWPFTable clonarTabelaModelo(XWPFTable tabelaModelo, XWPFDocument doc) {
        CTTbl tabelaCT = (CTTbl) tabelaModelo.getCTTbl().copy(); // cópia profunda da estrutura da tabela
        return new XWPFTable(tabelaCT, doc);
    }

    public static void gerar(Aluno aluno) throws Exception {
        System.out.println("Quantidade de atividades recebidas: " + aluno.getAtividades().size());
        for (Atividade atv : aluno.getAtividades()) {
            System.out.println(atv.getTipo() + " - " + atv.getCarac().getDescricao());
        }
        
        String caminhoModelo = "RelatorioAtividades.docx"; // se estiver na raiz do projeto
        String caminhoSaida = "RelatorioPreenchido.docx"; // será salvo na mesma pasta do projeto

        FileInputStream fis = new FileInputStream(caminhoModelo);
        XWPFDocument doc = new XWPFDocument(fis);

        Map<String, String> substituicoes = new HashMap<>();
        substituicoes.put("{{NOME}}", aluno.getNome());
        substituicoes.put("{{RA}}", String.valueOf(aluno.getRA()));
        substituicoes.put("{{CURSO}}", aluno.getCurso());
        substituicoes.put("{{COD_CURSO}}", String.valueOf(aluno.getCodCurso()));
        substituicoes.put("{{EMAIL}}", aluno.getEmail());

        substituirTextoNoDocumento(doc, substituicoes);
        
        Map<String, String> substituicoesPontos = new HashMap<>();
        substituicoesPontos.put("{{SOMAG1}}", Integer.toString(aluno.getTotalAtividade().getSomaG1()));
        substituicoesPontos.put("{{SOMAG2}}", Integer.toString(aluno.getTotalAtividade().getSomaG2()));
        substituicoesPontos.put("{{SOMAG3}}", Integer.toString(aluno.getTotalAtividade().getSomaG3()));
        substituicoesPontos.put("{{SOMAPONTOS}}", Integer.toString(aluno.getTotalAtividade().getSomaPontosTotal()));

        substituirTextoNoDocumento(doc, substituicoesPontos);

        XWPFTable tabelaModelo = doc.getTables().get(1); // tabela de modelo de atividade
        // Clona a tabela modelo original ANTES de preenchê-la
        XWPFTable tabelaModeloOriginal = clonarTabelaModelo(tabelaModelo, doc);

        XmlCursor cursorPosicao = tabelaModelo.getCTTbl().newCursor();
        cursorPosicao.toNextSibling(); // posiciona após a tabela modelo
        // Insere um parágrafo vazio para espaço entre tabelas
        XWPFParagraph paragrafoEspaco = doc.insertNewParagraph(cursorPosicao);
        paragrafoEspaco.createRun().setText("");  // parágrafo vazio
        paragrafoEspaco.setSpacingAfter(300);    // espaçamento depois do parágrafo (valor em twips)

        cursorPosicao = paragrafoEspaco.getCTP().newCursor();
        cursorPosicao.toNextSibling();

        // Armazena as atividades
        List<Atividade> atividades = aluno.getAtividades();

        // Verifica se há pelo menos uma atividade
        if (!atividades.isEmpty()) {
            for (int i = 0; i < atividades.size(); i++) {
                Atividade atv = atividades.get(i);
                
                // Prepara os dados da atividade
                Map<String, String> subAtividade = new HashMap<>();
                subAtividade.put("{{TIPO}}", atv.getTipo());
                subAtividade.put("{{GRUPO}}", String.valueOf(atv.getGrupo()));
                subAtividade.put("{{ID}}", String.valueOf((i+1)));
                subAtividade.put("{{DESCRICAO}}", atv.getCarac().getDescricao());
                subAtividade.put("{{INICIO}}", formatarData(atv.getCarac().getInicio()));
                subAtividade.put("{{TERMINO}}", formatarData(atv.getCarac().getFim()));
                subAtividade.put("{{PONTOS}}", String.valueOf(atv.getPontos()));
                subAtividade.put("{{DURACAO}}", atv.getCarac().getDuracao() + " " + atv.getCarac().getUnidade());

                if (i == 0) {
    // Primeira atividade: usa a tabela modelo existente no documento
                    substituirTextoNoDocumento(tabelaModelo, subAtividade);
                } else {
                    // Clona a tabela modelo ORIGINAL (com placeholders intactos)
                    XWPFTable novaTabela = clonarTabelaModelo(tabelaModeloOriginal, doc);

                    // Preenche a nova tabela com os dados da atividade
                    substituirTextoNoDocumento(novaTabela, subAtividade);

                    // Insere a nova tabela no documento
                    XWPFTable tabelaInserida = doc.insertNewTbl(cursorPosicao);
                    tabelaInserida.getCTTbl().set(novaTabela.getCTTbl());

                    // Atualiza o cursor para a próxima inserção
                    cursorPosicao = tabelaInserida.getCTTbl().newCursor();
                    cursorPosicao.toNextSibling();

                    paragrafoEspaco = doc.insertNewParagraph(cursorPosicao);
                    paragrafoEspaco.createRun().setText("");  // parágrafo vazio
                    paragrafoEspaco.setSpacingAfter(300);    // ajusta o espaçamento depois do parágrafo (300 twips = ~15 pontos)

                    // Atualiza cursor para depois do parágrafo vazio
                    cursorPosicao = paragrafoEspaco.getCTP().newCursor();
                    cursorPosicao.toNextSibling();
                }
            }
        }

        FileOutputStream fos = new FileOutputStream(caminhoSaida);
        doc.write(fos);
        fos.close();
        doc.close();
        fis.close();

        JOptionPane.showMessageDialog( 
                null,
                "Documento gerado com sucesso em: "+caminhoSaida,
                "Sucesso",
                JOptionPane.INFORMATION_MESSAGE
        );

    }
}
