package controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTbl;

public class PreencherRelatorio {

    public static void main(String[] args) throws Exception {
        String caminhoEntrada = "C:\\Users\\pambe\\Downloads\\Relatorio-Pontuacao.docx";
        String caminhoSaida = "C:\\Users\\pambe\\OneDrive\\Área de Trabalho\\Relatorio-Preenchido.docx";

        // Mapa de substituição
        Map<String, String> substituicoes = new HashMap<>();
        substituicoes.put("NOME", "Maria Clara");
        substituicoes.put("RA", "2601435");
        substituicoes.put("CURSO", "Engenharia de Software");
        substituicoes.put("EMAIL", "maria@email.com");
        substituicoes.put("COD_CURSO", "ESW123");
        substituicoes.put("TIPO", "Evento");
        substituicoes.put("DESCRICAO", "Participação no Congresso");
        substituicoes.put("GRUPO", "G2");
        substituicoes.put("INICIO", "01/04/2025");
        substituicoes.put("TERMINO", "05/04/2025");
        substituicoes.put("DURACAO", "5 dias");
        substituicoes.put("PONTOS", "10");
        substituicoes.put("ID", "A123");
        substituicoes.put("SOMAG1", "5");
        substituicoes.put("SOMAG2", "10");
        substituicoes.put("SOMAG3", "8");
        substituicoes.put("SOMAPONTOS", "23");

        // Carrega o documento principal
        FileInputStream fis = new FileInputStream(caminhoEntrada);
        XWPFDocument doc = new XWPFDocument(fis);

        // Carrega o modelo para copiar a tabela e insere no documento principal
        try (FileInputStream modeloInput = new FileInputStream("C:\\Users\\pambe\\Downloads\\Relatorio-Pontuacao.docx");
             XWPFDocument docModelo = new XWPFDocument(modeloInput)) {

            // Copia a primeira tabela do modelo
            XWPFTable tabelaModelo = docModelo.getTables().get(1);
            
            CTTbl tabelaClonadaCT = (CTTbl) tabelaModelo.getCTTbl().copy();
            
            int posOriginal = doc.getBodyElements().indexOf(tabelaModelo);

            doc.createTable();
            doc.getDocument().getBody().insertNewTbl(posOriginal + 1).set(tabelaClonadaCT);

            XWPFTable tabelaNova = doc.getTables().get(posOriginal + 1);

            // (Opcional) Substitui os placeholders da nova tabela
            for (XWPFTableRow linha : tabelaNova.getRows()) {
                for (XWPFTableCell celula : linha.getTableCells()) {
                    for (XWPFParagraph par : celula.getParagraphs()) {
                        substituirRuns(par, substituicoes);
                    }
                }
            }
        }

        // Substitui placeholders em parágrafos normais
        for (XWPFParagraph par : doc.getParagraphs()) {
            substituirRuns(par, substituicoes);
        }

        // Substitui placeholders em tabelas já existentes (incluindo a nova)
        for (XWPFTable tabela : doc.getTables()) {
            for (XWPFTableRow linha : tabela.getRows()) {
                for (XWPFTableCell celula : linha.getTableCells()) {
                    for (XWPFParagraph par : celula.getParagraphs()) {
                        substituirRuns(par, substituicoes);
                    }
                }
            }
        }

        // Salva o novo documento preenchido
        FileOutputStream fos = new FileOutputStream(caminhoSaida);
        doc.write(fos);
        fos.close();
        doc.close();
        fis.close();

        System.out.println("Documento preenchido com sucesso!");
    }

    private static void substituirRuns(XWPFParagraph par, Map<String, String> substituicoes) {
        StringBuilder textoCompleto = new StringBuilder();
        for (XWPFRun run : par.getRuns()) {
            String texto = run.getText(0);
            if (texto != null) {
                textoCompleto.append(texto);
            }
        }

        String textoFinal = textoCompleto.toString();
        boolean alterado = false;

        for (String chave : substituicoes.keySet()) {
            String placeholder = "{{" + chave + "}}";
            if (textoFinal.contains(placeholder)) {
                textoFinal = textoFinal.replace(placeholder, substituicoes.get(chave));
                alterado = true;
            }
        }

        if (alterado) {
            int totalRuns = par.getRuns().size();
            for (int i = totalRuns - 1; i >= 0; i--) {
                par.removeRun(i);
            }

            XWPFRun novoRun = par.createRun();
            novoRun.setText(textoFinal, 0);
        }
    }
}
