package controller;

public class Atividade{
    private int id;
    private String tipo;
    private int pontos;
    private Caracteristica carac;
    
    public Atividade(){
        id = 0;
        tipo = "";
        pontos = 0;
        carac = new Caracteristica();
    }
    
    public Atividade(int id, String tipo, int pontos, Caracteristica carac){
        this.id = id;
        this.tipo = tipo;
        this.pontos = pontos;
        this.carac = carac;
    }
    
    public int getId(){
        return id;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public int getPontos(){
        return pontos;
    }
    
    public Caracteristica getCarac(){
        return carac;
    }
    
    
    public void setId(int id){
        this.id = id;
    }
    
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    
    public void setPontos(int pontos){
        this.pontos = pontos;
    }
    
    public void setCarac(Caracteristica carac){
        this.carac = carac;
    }
}
