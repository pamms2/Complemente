package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Aluno;

public class AlunoDAO {
    
    /*
    public void cadastrarAluno(Aluno aluno) {
        String sql = "INSERT INTO aluno (ra, senha, nome, email, curso, codCurso) VALUES (?, ?, ?, ? , ?, ?)";
    
        try(Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, aluno.getRa());
            stmt.setString(2, aluno.getSenha());
            stmt.setString(3, aluno.getNome());
            stmt.setString(4, aluno.getEmail());
            stmt.setString(5, aluno.getCurso());
            stmt.setInt(6, aluno.getCodCurso());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public Aluno consultarAluno(int ra) {
        String sql = "SELECT * FROM aluno WHERE ra = ?";;;
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, ra);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Aluno(
                    rs.getInt("ra"),
                    rs.getString("senha"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("curso"),
                    rs.getInt("codCurso")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

*/
    
    public void atualizarAluno() {
        
    }
    
    public void excluirAluno() {
        
    }
    
    public void logarAluno() {
        
    }
}
