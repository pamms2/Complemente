package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import model.Aluno;

public class AlunoDAO {
    
    public void adicionarAluno(Aluno aluno) {
        String sql = "INSERT INTO Aluno (RA, nome, email, senha, cod_curso, curso) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            Connection con = Conexao.getConexao();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, aluno.getRA());
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getEmail());
            ps.setString(4, aluno.getSenha());
            ps.setInt(5, aluno.getCodCurso());
            ps.setString(6, aluno.getCurso());
            ps.executeUpdate();
            ps.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void consultarAluno() {
        String sql = "SELECT *FROM Aluno";
        
        try {
            Connection con = Conexao.getConexao();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery(sql);
            while(rs.next()) {
                System.out.println("RA = "+rs.getInt(1));
                System.out.println("Nome = "+rs.getString(2));
                System.out.println("E-mail = "+rs.getString(3));
                System.out.println("Senha = "+rs.getString(4));
                System.out.println("Codigo Curso = "+rs.getInt(5));
                System.out.println("Curso = "+rs.getString(6));
            }
            ps.close();
            rs.close();
            con.close();
        } catch(Exception e) {
            System.out.println(e);
        }
    }
    
    public void excluirAluno(int ra, String senha) {
        String sql = "DELETE FROM Aluno WHERE ra = ? AND senha = ?";

        try {
            Connection con = Conexao.getConexao();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, ra);
            ps.setString(2, senha);

            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Aluno excluído com sucesso!");
            } else {
                System.out.println("RA ou senha incorretos. Nenhum aluno foi excluído.");
            }

            ps.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public void atualizarAluno(int ra, String senhaAtual, Aluno alunoAtualizado) {
        String sql = "UPDATE Aluno SET nome = ?, email = ?, senha = ?, curso = ?, codCurso = ? WHERE ra = ? AND senha = ?";

        try {
            Connection con = Conexao.getConexao();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, alunoAtualizado.getNome());
            ps.setString(2, alunoAtualizado.getEmail());
            ps.setString(3, alunoAtualizado.getSenha());
            ps.setString(4, alunoAtualizado.getCurso());
            ps.setInt(5, alunoAtualizado.getCodCurso());
            ps.setInt(6, ra);
            ps.setString(7, senhaAtual);

            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Dados do aluno atualizados com sucesso!");
            } else {
                System.out.println("RA ou senha incorretos. Nenhuma atualização realizada.");
            }
            ps.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }    
    
}
