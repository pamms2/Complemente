package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Aluno;

public class AlunoDAO {

    public void adicionarAluno(Aluno aluno) throws SQLException {
        String sql = "INSERT INTO Aluno (RA, nome, email, senha, codCurso, curso) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, aluno.getRA());
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getEmail());
            ps.setString(4, aluno.getSenha());
            ps.setInt(5, aluno.getCodCurso());
            ps.setString(6, aluno.getCurso());

            ps.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Erro ao adicionar aluno:");
            e.printStackTrace();
        }
    }
    
    public Aluno autenticar(String raStr, String senha) throws SQLException {
        int ra;
        try {
            ra = Integer.parseInt(raStr);
        } catch (NumberFormatException e) {
            return null; 
        }

        String sql = "SELECT * FROM Aluno WHERE RA = ? AND senha = ?";

        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ra);
            ps.setString(2, senha);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Aluno aluno = new Aluno();
                    aluno.setRA(rs.getInt("RA"));
                    aluno.setNome(rs.getString("nome"));
                    aluno.setEmail(rs.getString("email"));
                    aluno.setSenha(rs.getString("senha"));
                    aluno.setCodCurso(rs.getInt("codCurso"));
                    aluno.setCurso(rs.getString("curso"));
                    return aluno;
                } else {
                    return null;
                }
            }
        } catch(SQLException e) {
            System.err.println("Erro ao adicionar aluno:");
            e.printStackTrace();
        }
        return null;
    }


    public void consultarAluno() {
        String sql = "SELECT * FROM Aluno";

        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println("RA = " + rs.getInt("RA"));
                System.out.println("Nome = " + rs.getString("nome"));
                System.out.println("E-mail = " + rs.getString("email"));
                System.out.println("Senha = " + rs.getString("senha"));
                System.out.println("Codigo Curso = " + rs.getInt("codCurso"));
                System.out.println("Curso = " + rs.getString("curso"));
            }

        } catch (SQLException e) {
            System.err.println("Erro ao consultar alunos:");
            e.printStackTrace();
        }
    }

    public void excluirAluno(int ra, String senha) {
        String sql = "DELETE FROM Aluno WHERE RA = ? AND senha = ?";

        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ra);
            ps.setString(2, senha);

            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Aluno excluído com sucesso!");
            } else {
                System.out.println("RA ou senha incorretos. Nenhum aluno foi excluído.");
            }

        } catch (SQLException e) {
            System.err.println("Erro ao excluir aluno:");
            e.printStackTrace();
        }
    }

    public void atualizarAluno(int ra, String senhaAtual, Aluno alunoAtualizado) {
        String sql = "UPDATE Aluno SET nome = ?, email = ?, senha = ?, curso = ?, codCurso = ? WHERE RA = ? AND senha = ?";

        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, alunoAtualizado.getNome());
            ps.setString(2, alunoAtualizado.getEmail());
            ps.setString(3, alunoAtualizado.getSenha());
            ps.setString(4, alunoAtualizado.getCurso());
            ps.setInt(5, alunoAtualizado.getCodCurso());
            ps.setInt(6, ra);
            ps.setString(7, senhaAtual);

            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Dados do aluno atualizados com sucesso!");
            } else {
                System.out.println("RA ou senha incorretos. Nenhuma atualização realizada.");
            }

        } catch (SQLException e) {
            System.err.println("Erro ao atualizar aluno:");
            e.printStackTrace();
        }
    }
}
