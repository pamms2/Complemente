package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Aluno;

public class AlunoDAO {
    
public void adicionarAluno(Aluno aluno) {
    String sql = "INSERT INTO Aluno (RA, nome, email, senha, cod_curso, curso) VALUES (?, ?, ?, ?, ?, ?)";

    try {
        Connection con = Conexao.getConexao();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, aluno.getRA());
        ps.setString(2, aluno.getNome());
        ps.setString(3, aluno.getEmail());
        ps.setString(4, aluno.getSenha());
        ps.setInt(5, aluno.getCodCurso());
        ps.setString(6, aluno.getCurso());
        ps.executeUpdate();
        ps.close();
        con.close();
    } catch (Exception e) {
        System.out.println("Erro ao inserir aluno: " + e.getMessage());
    }
}

    public void consultarAluno() {
        String sql = "SELECT *FROM Aluno";
        
        try {
            Connection con = Conexao.getConexao();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery(sql);
            while(rs.next()) {
                System.out.println("RA = "+rs.getInt(1));
                System.out.println("Nome = "+rs.getString(2));
                System.out.println("E-mail = "+rs.getString(3));
                System.out.println("Senha = "+rs.getString(4));
                System.out.println("Codigo Curso = "+rs.getInt(5));
                System.out.println("Curso = "+rs.getString(6));
            }
            ps.close();
            rs.close();
            con.close();
        } catch(Exception e) {
            System.out.println(e);
        }
    }
    
    public void excluirAluno(Aluno aluno) {
        
    } 
    
}
