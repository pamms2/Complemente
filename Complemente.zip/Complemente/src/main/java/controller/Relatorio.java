package controller;

public interface Relatorio {
    public void gerarRelatorio();
}
