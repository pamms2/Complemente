package controller;

import model.Aluno;
import model.Atividade;
import model.Caracteristica;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.poi.xwpf.usermodel.*;
import org.apache.xmlbeans.XmlException;

public class Relatorio {

    // Método para substituir textos em um parágrafo
    private static void substituirTexto(XWPFParagraph paragrafo, Map<String, String> substituicoes) {
        StringBuilder textoCompleto = new StringBuilder();
        List<XWPFRun> runs = paragrafo.getRuns();

        for (XWPFRun run : runs) {
            if (run.getText(0) != null) {
                textoCompleto.append(run.getText(0));
            }
        }

        String textoFinal = textoCompleto.toString();

        for (Map.Entry<String, String> entry : substituicoes.entrySet()) {
            textoFinal = textoFinal.replace(entry.getKey(), entry.getValue());
        }

        // Remove todos os runs e adiciona um novo com o texto completo substituído
        for (int i = runs.size() - 1; i >= 0; i--) {
            paragrafo.removeRun(i);
        }

        XWPFRun novoRun = paragrafo.createRun();
        novoRun.setText(textoFinal);
    }

    // Substitui em todo o documento (parágrafos e tabelas)
    private static void substituirTextoNoDocumento(XWPFDocument doc, Map<String, String> substituicoes) {
        for (XWPFParagraph p : doc.getParagraphs()) {
            substituirTexto(p, substituicoes);
        }
        for (XWPFTable tabela : doc.getTables()) {
            for (XWPFTableRow linha : tabela.getRows()) {
                for (XWPFTableCell celula : linha.getTableCells()) {
                    for (XWPFParagraph p : celula.getParagraphs()) {
                        substituirTexto(p, substituicoes);
                    }
                }
            }
        }
    }

    // Formata uma data no formato dd/MM/yyyy, retorna "" se data for null
    private static String formatarData(Date data) {
        if (data == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(data);
    }

    // Cria um objeto Aluno de exemplo com datas corrigidas
    private static Aluno criarAlunoExemplo() {
        List<Atividade> listaAtividades = new ArrayList<>();
        Aluno aluno = new Aluno(2564254, "hdamds43", "Pamela Berti Braz", "pbraz@alunos.utfpr.edu.br", "Engenharia de Software", 81, listaAtividades);

        Calendar cal = Calendar.getInstance();

        // Datas corrigidas: início antes do término
        cal.set(2004, Calendar.NOVEMBER, 2);
        Date dataInicio = cal.getTime();

        cal.set(2005, Calendar.DECEMBER, 5);
        Date dataFim = cal.getTime();

        Caracteristica carac1 = new Caracteristica("Participação em evento", dataFim, 15, "meses", dataInicio);

        cal.set(2025, Calendar.JANUARY, 15);
        dataInicio = cal.getTime();

        cal.set(2025, Calendar.APRIL, 15);
        dataFim = cal.getTime();

        Caracteristica carac2 = new Caracteristica("Orgia", dataFim, 3, "meses", dataInicio);

        aluno.adicionarAtividade(new Atividade(1, "Palestra", 5, carac1, 1));
        aluno.adicionarAtividade(new Atividade(2, "Curso", 15, carac2, 2));

        return aluno;
    }

    public static void main(String[] args) throws Exception {
        String caminhoModelo = "C:\\Users\\pambe\\Downloads\\Relatorio-Pontuacao.docx";
        String caminhoSaida = "C:\\Users\\pambe\\OneDrive\\Área de Trabalho\\Relatorio-Preenchido.docx";

        Aluno aluno = criarAlunoExemplo();

        FileInputStream fis = new FileInputStream(caminhoModelo);
        XWPFDocument doc = new XWPFDocument(fis);

        // Substituir dados do aluno
        Map<String, String> substituicoes = new HashMap<>();
        substituicoes.put("{{NOME}}", aluno.getNome());
        substituicoes.put("{{RA}}", String.valueOf(aluno.getRa()));
        substituicoes.put("{{CURSO}}", aluno.getCurso());
        substituicoes.put("{{COD_CURSO}}", String.valueOf(aluno.getCodCurso()));
        substituicoes.put("{{EMAIL}}", aluno.getEmail());

        // Para simplificar, vamos usar a primeira atividade para preencher os campos
        List<Atividade> atividades = aluno.getAtividades();
        if (!atividades.isEmpty()) {
            Atividade atv = atividades.get(0);
            substituicoes.put("{{TIPO}}", atv.getTipo());
            substituicoes.put("{{GRUPO}}", String.valueOf(atv.getGrupo()));
            substituicoes.put("{{ID}}", String.valueOf(atv.getId()));
            substituicoes.put("{{DESCRICAO}}", atv.getCarac().getDescricao());
            substituicoes.put("{{INICIO}}", formatarData(atv.getCarac().getInicio()));
            substituicoes.put("{{TERMINO}}", formatarData(atv.getCarac().getFim()));
            substituicoes.put("{{PONTOS}}", String.valueOf(atv.getPontos()));
            substituicoes.put("{{DURACAO}}", atv.getCarac().getDuracao() + " " + atv.getCarac().getUnidade());
            System.out.println("Tipo: " + atv.getTipo());
            System.out.println("Grupo: " + atv.getGrupo());
            System.out.println("ID: " + atv.getId());

        }
        

        substituirTextoNoDocumento(doc, substituicoes);

        FileOutputStream fos = new FileOutputStream(caminhoSaida);
        doc.write(fos);
        fos.close();
        doc.close();
        fis.close();

        System.out.println("Documento gerado: " + caminhoSaida);
    }
}
