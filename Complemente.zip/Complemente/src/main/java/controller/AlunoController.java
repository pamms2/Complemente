package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import model.Aluno;

public class AlunoController {
    
    static Connection con = null;    
    static String url =  "jdbc:mysql://localhost:3306/complemente";
    static String driver = "com.mysql.cj.jdbc.Driver";
    static String user = "root";
    static String senha = "12345";
    
    static Statement st = null;
    PreparedStatement ps = null;

    public void adicionarAluno(Aluno aluno) throws SQLException {
        String sql = "INSERT INTO Aluno (RA, nome, email, senha, codCurso, curso) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DAO.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, aluno.getRA());
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getEmail());
            ps.setString(4, aluno.getSenha());
            ps.setInt(5, aluno.getCodCurso());
            ps.setString(6, aluno.getCurso());

            ps.executeUpdate();

        } 
    }
    
    public Aluno autenticar(String raStr, String senha) throws SQLException {
        int ra;
        try {
            ra = Integer.parseInt(raStr);
        } catch (NumberFormatException e) {
            return null; 
        }

        String sql = "SELECT * FROM Aluno WHERE RA = ? AND senha = ?";

        try (Connection con = DAO.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ra);
            ps.setString(2, senha);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Aluno aluno = new Aluno();
                    aluno.setRA(rs.getInt("RA"));
                    aluno.setNome(rs.getString("nome"));
                    aluno.setEmail(rs.getString("email"));
                    aluno.setSenha(rs.getString("senha"));
                    aluno.setCodCurso(rs.getInt("codCurso"));
                    aluno.setCurso(rs.getString("curso"));
                    return aluno;
                } else {
                    return null;
                }
            }
        } catch(SQLException e) {
            System.err.println("Erro ao adicionar aluno:");
            e.printStackTrace();
        }
        return null;
    }


    public void consultarAluno() {
        String sql = "SELECT * FROM Aluno";

        try (Connection con = DAO.getConexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println("RA = " + rs.getInt("RA"));
                System.out.println("Nome = " + rs.getString("nome"));
                System.out.println("E-mail = " + rs.getString("email"));
                System.out.println("Senha = " + rs.getString("senha"));
                System.out.println("Codigo Curso = " + rs.getInt("codCurso"));
                System.out.println("Curso = " + rs.getString("curso"));
            }

        } catch (SQLException e) {
            System.err.println("Erro ao consultar alunos:");
            e.printStackTrace();
        }
    }

    public void excluirAluno(int ra, String senha) throws SQLException {
        String sqlCheck = "SELECT COUNT(*) FROM Aluno WHERE ra = ? AND senha = ?";
        String sqlExcluirAtividades = "DELETE FROM Atividade WHERE ra = ?";
        String sqlExcluirAluno = "DELETE FROM Aluno WHERE ra = ? AND senha = ?";

        try (Connection con = DAO.getConexao()) {
            // Verificar se aluno existe e senha confere
            try (PreparedStatement psCheck = con.prepareStatement(sqlCheck)) {
                psCheck.setInt(1, ra);
                psCheck.setString(2, senha);
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next()) {
                        int count = rs.getInt(1);
                        if (count == 0) {
                            throw new SQLException("Aluno não encontrado ou senha incorreta.");
                        }
                    }
                }
            }

            // Exclui todas as atividades vinculadas ao aluno
            try (PreparedStatement psAtividades = con.prepareStatement(sqlExcluirAtividades)) {
                psAtividades.setInt(1, ra);
                psAtividades.executeUpdate();
            }

            // Exclui o aluno
            try (PreparedStatement psAluno = con.prepareStatement(sqlExcluirAluno)) {
                psAluno.setInt(1, ra);
                psAluno.setString(2, senha);
                int linhasAfetadas = psAluno.executeUpdate();

                if (linhasAfetadas == 0) {
                    throw new SQLException("Falha ao excluir aluno.");
                }
            }
        }
    }

    public void atualizarAluno(Aluno alunoAtualizado) throws SQLException{
        String sql = "UPDATE Aluno SET nome = ?, email = ?, senha = ?, curso = ?, codCurso = ? WHERE RA = ? AND senha = ?";

        try (Connection con = DAO.getConexao();
            PreparedStatement ps = con.prepareStatement(sql)) {

            //Altera os dados do aluno, mantendo tudo salvo
            ps.setString(1, alunoAtualizado.getNome());
            ps.setString(2, alunoAtualizado.getEmail());
            ps.setString(3, alunoAtualizado.getSenha());
            ps.setString(4, alunoAtualizado.getCurso());
            ps.setInt(5, alunoAtualizado.getCodCurso());
            ps.setInt(6, alunoAtualizado.getRA());
            ps.setString(7, alunoAtualizado.getSenha());

            ps.executeUpdate();
        }
    }
    
    public void atualizarSenha(int ra, String senhaAntiga, String novaSenha) throws SQLException {
        String sql = "UPDATE Aluno SET senha = ? WHERE RA = ? AND senha = ?";

        try (Connection con = DAO.getConexao();
            PreparedStatement ps = con.prepareStatement(sql)) {

            //atualiza a senha caso o usuário acerte a senha antiga 
            ps.setString(1, novaSenha);      
            ps.setInt(2, ra);                
            ps.setString(3, senhaAntiga);    

            int linhasAfetadas = ps.executeUpdate();
            if (linhasAfetadas == 0) {
                throw new SQLException("Senha incorreta ou aluno não encontrado.");
            }
        }
    }

}
