package view;

public class SelecaoAtividadeGUI extends javax.swing.JFrame {
    
    private static SelecaoAtividadeGUI selecaoAtividadeUnic;

    public static SelecaoAtividadeGUI geraSelecaoAtividadeGUI() {
        if(selecaoAtividadeUnic == null) {
            selecaoAtividadeUnic = new SelecaoAtividadeGUI();
        }
        return selecaoAtividadeUnic;
    }
    
    public SelecaoAtividadeGUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonAdicionarAtividade = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonAdicionarAtividade.setText("Adicionar ");
        jButtonAdicionarAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdicionarAtividadeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(265, Short.MAX_VALUE)
                .addComponent(jButtonAdicionarAtividade)
                .addGap(51, 51, 51))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(jButtonAdicionarAtividade)
                .addContainerGap(179, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAdicionarAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdicionarAtividadeActionPerformed
        abreCadastroAtividadeGUI();
    }//GEN-LAST:event_jButtonAdicionarAtividadeActionPerformed

    public void abreCadastroAtividadeGUI() {
        CadastroAtividadeGUI.geraCadastroAtividadeGUI().setVisible(true);
        dispose();
    }
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SelecaoAtividadeGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdicionarAtividade;
    // End of variables declaration//GEN-END:variables
}
