package view;

public class SelecaoAtividadeGUI extends javax.swing.JFrame {
    
    private static SelecaoAtividadeGUI selecaoAtividadeUnic;

    public static SelecaoAtividadeGUI geraSelecaoAtividadeGUI() {
        if(selecaoAtividadeUnic == null) {
            selecaoAtividadeUnic = new SelecaoAtividadeGUI();
        }
        return selecaoAtividadeUnic;
    }
    
    public SelecaoAtividadeGUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonAdicionarAtividade = new javax.swing.JButton();
        jLabelTitulo = new javax.swing.JLabel();
        jLabelGrupo1 = new javax.swing.JLabel();
        jCheckBoxPrimeira = new javax.swing.JCheckBox();
        jLabelGrupo2 = new javax.swing.JLabel();
        jLabelGrupo3 = new javax.swing.JLabel();
        jLabelTipo = new javax.swing.JLabel();
        jLabelTipoPreenchido = new javax.swing.JLabel();
        jLabelDescricao = new javax.swing.JLabel();
        jLabelDescricaoPreenchido = new javax.swing.JLabel();
        jLabelPeriodo = new javax.swing.JLabel();
        jLabelInicio = new javax.swing.JLabel();
        jLabelTermino = new javax.swing.JLabel();
        jLabelA = new javax.swing.JLabel();
        jLabelDuracao = new javax.swing.JLabel();
        jLabelQtd = new javax.swing.JLabel();
        jLabelTempo = new javax.swing.JLabel();
        jLabelPontos = new javax.swing.JLabel();
        jLabelQtdPontos = new javax.swing.JLabel();
        jCheckBoxPrimeira2 = new javax.swing.JCheckBox();
        jLabelTipo2 = new javax.swing.JLabel();
        jLabelTipoPreenchido2 = new javax.swing.JLabel();
        jLabelDescricao2 = new javax.swing.JLabel();
        jLabelDescricaoPreenchido2 = new javax.swing.JLabel();
        jLabelPeriodo2 = new javax.swing.JLabel();
        jLabelInicio2 = new javax.swing.JLabel();
        jLabelA2 = new javax.swing.JLabel();
        jLabelTermino2 = new javax.swing.JLabel();
        jLabelDuracao2 = new javax.swing.JLabel();
        jLabelQtd2 = new javax.swing.JLabel();
        jLabelTempo1 = new javax.swing.JLabel();
        jLabelmensagem = new javax.swing.JLabel();
        jLabelPontos2 = new javax.swing.JLabel();
        jLabelQtdPontos2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonAdicionarAtividade.setText("Gerar Relatório ");
        jButtonAdicionarAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdicionarAtividadeActionPerformed(evt);
            }
        });

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTitulo.setText("Lista de Atividades");

        jLabelGrupo1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo1.setText("Grupo 1");

        jCheckBoxPrimeira.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxPrimeiraActionPerformed(evt);
            }
        });

        jLabelGrupo2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo2.setText("Grupo 2");

        jLabelGrupo3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo3.setText("Grupo 3");

        jLabelTipo.setText("Tipo:");

        jLabelTipoPreenchido.setText("Tipo preenchido");

        jLabelDescricao.setText("Descrição:");

        jLabelDescricaoPreenchido.setText("Descrição preenchida");

        jLabelPeriodo.setText("Período:");

        jLabelInicio.setText("01/01/2001");

        jLabelTermino.setText("31/12/2001");

        jLabelA.setText("a");

        jLabelDuracao.setText("Duração:");

        jLabelQtd.setText("Qtd");

        jLabelTempo.setText("Tempo");

        jLabelPontos.setText("Pontos:");

        jLabelQtdPontos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQtdPontos.setText("30");

        jCheckBoxPrimeira2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxPrimeira2ActionPerformed(evt);
            }
        });

        jLabelTipo2.setText("Tipo:");

        jLabelTipoPreenchido2.setText("Tipo preenchido");

        jLabelDescricao2.setText("Descrição:");

        jLabelDescricaoPreenchido2.setText("Descrição preenchida");

        jLabelPeriodo2.setText("Período:");

        jLabelInicio2.setText("01/01/2001");

        jLabelA2.setText("a");

        jLabelTermino2.setText("31/12/2001");

        jLabelDuracao2.setText("Duração:");

        jLabelQtd2.setText("Qtd");

        jLabelTempo1.setText("Tempo");

        jLabelmensagem.setForeground(new java.awt.Color(255, 0, 0));
        jLabelmensagem.setText("Mensagem de quantidade mínima ou máxima");

        jLabelPontos2.setText("Pontos:");

        jLabelQtdPontos2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQtdPontos2.setText("10");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelPeriodo, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelDuracao, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabelDescricaoPreenchido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelQtd, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabelTempo, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabelQtdPontos2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabelPontos2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabelA, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabelTermino, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabelQtdPontos, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(32, 32, 32))))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelmensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabelTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelTipoPreenchido, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                        .addComponent(jLabelPontos, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32))))
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBoxPrimeira)
                    .addComponent(jLabelGrupo2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelGrupo3, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelGrupo1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBoxPrimeira2)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabelTipo2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelTipoPreenchido2, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelDescricao2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelPeriodo2, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelDuracao2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelDescricaoPreenchido2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabelInicio2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabelQtd2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabelA2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabelTermino2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabelTempo1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE))))))))
            .addGroup(layout.createSequentialGroup()
                .addGap(128, 128, 128)
                .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonAdicionarAtividade)
                .addGap(211, 211, 211))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabelTitulo)
                .addGap(46, 46, 46)
                .addComponent(jLabelGrupo1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTipo)
                    .addComponent(jLabelTipoPreenchido)
                    .addComponent(jLabelPontos))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBoxPrimeira)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelDescricao)
                        .addComponent(jLabelDescricaoPreenchido)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelPeriodo)
                    .addComponent(jLabelInicio)
                    .addComponent(jLabelTermino)
                    .addComponent(jLabelA)
                    .addComponent(jLabelQtdPontos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDuracao)
                    .addComponent(jLabelQtd)
                    .addComponent(jLabelTempo))
                .addGap(18, 18, 18)
                .addComponent(jLabelmensagem)
                .addGap(23, 23, 23)
                .addComponent(jLabelGrupo2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelTipo2)
                            .addComponent(jLabelTipoPreenchido2))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBoxPrimeira2)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelDescricao2)
                                .addComponent(jLabelDescricaoPreenchido2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelPeriodo2)
                            .addComponent(jLabelInicio2)
                            .addComponent(jLabelTermino2)
                            .addComponent(jLabelA2)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelPontos2)
                        .addGap(34, 34, 34)
                        .addComponent(jLabelQtdPontos2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDuracao2)
                    .addComponent(jLabelQtd2)
                    .addComponent(jLabelTempo1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                .addComponent(jLabelGrupo3)
                .addGap(40, 40, 40)
                .addComponent(jButtonAdicionarAtividade)
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAdicionarAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdicionarAtividadeActionPerformed
        abreCadastroAtividadeGUI();
    }//GEN-LAST:event_jButtonAdicionarAtividadeActionPerformed

    private void jCheckBoxPrimeiraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxPrimeiraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxPrimeiraActionPerformed

    private void jCheckBoxPrimeira2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxPrimeira2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxPrimeira2ActionPerformed

    public void abreCadastroAtividadeGUI() {
        CadastroAtividadeGUI.geraCadastroAtividadeGUI().setVisible(true);
        dispose();
    }
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SelecaoAtividadeGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdicionarAtividade;
    private javax.swing.JCheckBox jCheckBoxPrimeira;
    private javax.swing.JCheckBox jCheckBoxPrimeira2;
    private javax.swing.JLabel jLabelA;
    private javax.swing.JLabel jLabelA2;
    private javax.swing.JLabel jLabelDescricao;
    private javax.swing.JLabel jLabelDescricao2;
    private javax.swing.JLabel jLabelDescricaoPreenchido;
    private javax.swing.JLabel jLabelDescricaoPreenchido2;
    private javax.swing.JLabel jLabelDuracao;
    private javax.swing.JLabel jLabelDuracao2;
    private javax.swing.JLabel jLabelGrupo1;
    private javax.swing.JLabel jLabelGrupo2;
    private javax.swing.JLabel jLabelGrupo3;
    private javax.swing.JLabel jLabelInicio;
    private javax.swing.JLabel jLabelInicio2;
    private javax.swing.JLabel jLabelPeriodo;
    private javax.swing.JLabel jLabelPeriodo2;
    private javax.swing.JLabel jLabelPontos;
    private javax.swing.JLabel jLabelPontos2;
    private javax.swing.JLabel jLabelQtd;
    private javax.swing.JLabel jLabelQtd2;
    private javax.swing.JLabel jLabelQtdPontos;
    private javax.swing.JLabel jLabelQtdPontos2;
    private javax.swing.JLabel jLabelTempo;
    private javax.swing.JLabel jLabelTempo1;
    private javax.swing.JLabel jLabelTermino;
    private javax.swing.JLabel jLabelTermino2;
    private javax.swing.JLabel jLabelTipo;
    private javax.swing.JLabel jLabelTipo2;
    private javax.swing.JLabel jLabelTipoPreenchido;
    private javax.swing.JLabel jLabelTipoPreenchido2;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JLabel jLabelmensagem;
    // End of variables declaration//GEN-END:variables
}
