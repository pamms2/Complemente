package view;

public class PerfilAlunoGUI extends javax.swing.JFrame {

    private static PerfilAlunoGUI perfilAlunoUnic;
    
    public static PerfilAlunoGUI geraPerfilAlunoGUI() {
        if(perfilAlunoUnic == null) {
            perfilAlunoUnic = new PerfilAlunoGUI();
        }
        return perfilAlunoUnic;
    }
    
    public PerfilAlunoGUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelPerfilAluno = new javax.swing.JLabel();
        jButtonAtividade = new javax.swing.JButton();
        jLabelNome = new javax.swing.JLabel();
        jLabelRA = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jLabelCurso = new javax.swing.JLabel();
        jLabelNomePreenchido = new javax.swing.JLabel();
        jLabelRAPreenchido = new javax.swing.JLabel();
        jLabelEmailPreenchido = new javax.swing.JLabel();
        jLabelCursoPreenchido = new javax.swing.JLabel();
        jButtonAtualizar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableGrupos = new javax.swing.JTable();
        jLabelResumo = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelPerfilAluno.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelPerfilAluno.setText("PERFIL DO ALUNO");

        jButtonAtividade.setText("Cadastrar Atividade");
        jButtonAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtividadeActionPerformed(evt);
            }
        });

        jLabelNome.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelNome.setText("Nome:");

        jLabelRA.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelRA.setText("RA:");

        jLabelEmail.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelEmail.setText("E-mail:");

        jLabelCurso.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCurso.setText("Curso:");

        jLabelNomePreenchido.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelNomePreenchido.setText("Nome preenchido");

        jLabelRAPreenchido.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelRAPreenchido.setText("RA preenchido");

        jLabelEmailPreenchido.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelEmailPreenchido.setText("E-mail preenchido");

        jLabelCursoPreenchido.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCursoPreenchido.setText("curso preenchido");

        jButtonAtualizar.setText("Atualizar dados");

        jTableGrupos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Grupo 1", "", null, null},
                {"Grupo 2", null, null, null},
                {"Grupo 3", null, null, null},
                {"Total", null, null, null}
            },
            new String [] {
                "", "Horas  totais", "Horas cumpridas", "Aptidão"
            }
        ));
        jScrollPane1.setViewportView(jTableGrupos);

        jLabelResumo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelResumo.setText("Resumo de Atividades");

        jButton1.setText("Excluir Perfil");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelCurso, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelNome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelRA, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelPerfilAluno)
                            .addComponent(jLabelRAPreenchido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelNomePreenchido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelEmailPreenchido, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                            .addComponent(jLabelCursoPreenchido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(jButtonAtualizar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(213, 213, 213)
                        .addComponent(jLabelResumo))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(256, 256, 256)
                        .addComponent(jButtonAtividade)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 93, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabelPerfilAluno)
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(jLabelNomePreenchido))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelRA)
                    .addComponent(jLabelRAPreenchido))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelEmail)
                    .addComponent(jLabelEmailPreenchido))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCurso)
                    .addComponent(jLabelCursoPreenchido)
                    .addComponent(jButtonAtualizar))
                .addGap(76, 76, 76)
                .addComponent(jLabelResumo, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonAtividade)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(18, 18, 18))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtividadeActionPerformed
        abreSelecaoAtividadeGUI();
    }//GEN-LAST:event_jButtonAtividadeActionPerformed

    public void abreSelecaoAtividadeGUI() {
        SelecaoAtividadeGUI.geraSelecaoAtividadeGUI().setVisible(true);
        dispose();
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PerfilAlunoGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonAtividade;
    private javax.swing.JButton jButtonAtualizar;
    private javax.swing.JLabel jLabelCurso;
    private javax.swing.JLabel jLabelCursoPreenchido;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelEmailPreenchido;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelNomePreenchido;
    private javax.swing.JLabel jLabelPerfilAluno;
    private javax.swing.JLabel jLabelRA;
    private javax.swing.JLabel jLabelRAPreenchido;
    private javax.swing.JLabel jLabelResumo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableGrupos;
    // End of variables declaration//GEN-END:variables
}
