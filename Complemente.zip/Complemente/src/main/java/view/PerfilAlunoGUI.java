package view;

public class PerfilAlunoGUI extends javax.swing.JFrame {

    private static PerfilAlunoGUI perfilAlunoUnic;
    
    public static PerfilAlunoGUI geraPerfilAlunoGUI() {
        if(perfilAlunoUnic == null) {
            perfilAlunoUnic = new PerfilAlunoGUI();
        }
        return perfilAlunoUnic;
    }
    
    public PerfilAlunoGUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabelPerfilAluno = new javax.swing.JLabel();
        jButtonAtividade = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelPerfilAluno.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelPerfilAluno.setText("PERFIL DO ALUNO");

        jButtonAtividade.setText("Atividades");
        jButtonAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtividadeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(jLabelPerfilAluno))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(jButtonAtividade)))
                .addContainerGap(117, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel1)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabelPerfilAluno)
                .addGap(98, 98, 98)
                .addComponent(jButtonAtividade)
                .addContainerGap(126, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel1)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtividadeActionPerformed
        abreSelecaoAtividadeGUI();
    }//GEN-LAST:event_jButtonAtividadeActionPerformed

    public void abreSelecaoAtividadeGUI() {
        SelecaoAtividadeGUI.geraSelecaoAtividadeGUI().setVisible(true);
        dispose();
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PerfilAlunoGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAtividade;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelPerfilAluno;
    // End of variables declaration//GEN-END:variables
}
