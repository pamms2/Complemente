package view;

public class PerfilAlunoGUI extends javax.swing.JFrame {

    private static PerfilAlunoGUI perfilAlunoUnic;
    private static model.Aluno alunoLogado;
    
    public static PerfilAlunoGUI geraPerfilAlunoGUI() {
        if(perfilAlunoUnic == null) {
            perfilAlunoUnic = new PerfilAlunoGUI();
        }
        return perfilAlunoUnic;
    }
    
    public static void setAlunoLogado(model.Aluno aluno) {
        alunoLogado = aluno;
    }

    public static model.Aluno getAlunoLogado() {
        return alunoLogado;
    }

    
    public PerfilAlunoGUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelPerfilAluno = new javax.swing.JLabel();
        jButtonCadAtividade = new javax.swing.JButton();
        jButtonListaAtv = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelPerfilAluno.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelPerfilAluno.setText("PERFIL DO ALUNO");

        jButtonCadAtividade.setText("Cadastrar Atividades");
        jButtonCadAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCadAtividadeActionPerformed(evt);
            }
        });

        jButtonListaAtv.setText("Listar Atividades");
        jButtonListaAtv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonListaAtvActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(jLabelPerfilAluno))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(jButtonListaAtv))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(jButtonCadAtividade)))
                .addContainerGap(122, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabelPerfilAluno)
                .addGap(90, 90, 90)
                .addComponent(jButtonListaAtv)
                .addGap(30, 30, 30)
                .addComponent(jButtonCadAtividade)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonCadAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCadAtividadeActionPerformed
        abreSelecaoAtividadeGUI();
    }//GEN-LAST:event_jButtonCadAtividadeActionPerformed

    private void jButtonListaAtvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonListaAtvActionPerformed
        int ra = alunoLogado.getRA();
        new ListaAtividadesGUI(ra).setVisible(true);
    }//GEN-LAST:event_jButtonListaAtvActionPerformed

    public void abreSelecaoAtividadeGUI() {
        SelecaoAtividadeGUI.geraSelecaoAtividadeGUI().setVisible(true);
        dispose();
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PerfilAlunoGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCadAtividade;
    private javax.swing.JButton jButtonListaAtv;
    private javax.swing.JLabel jLabelPerfilAluno;
    // End of variables declaration//GEN-END:variables
}
