package view;

import controller.AlunoDAO;
import javax.swing.JOptionPane;
import model.Aluno;

public class CadastroAlunoGUI extends javax.swing.JFrame {
    
    private AlunoDAO alunoDAO = new AlunoDAO();
    private Aluno a = new Aluno();
    private static CadastroAlunoGUI cadastroAlunoUnic;

    
    public static CadastroAlunoGUI geraCadastroAlunoGUI() {
        if(cadastroAlunoUnic == null) {
            cadastroAlunoUnic = new CadastroAlunoGUI();
        }
        return cadastroAlunoUnic;
    }

    public CadastroAlunoGUI() {
      initComponents();
      jTextFieldCodCurso.setEditable(false);
      jComboBoxCurso.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            codigoCurso();
        }
    });
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelTitulo = new javax.swing.JLabel();
        jLabelNome = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jTextFieldRA = new javax.swing.JTextField();
        jLabelRA = new javax.swing.JLabel();
        jTextFieldSenha = new javax.swing.JTextField();
        jLabelSenha = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jTextFieldEmail = new javax.swing.JTextField();
        jLabelCurso = new javax.swing.JLabel();
        jComboBoxCurso = new javax.swing.JComboBox<>();
        jButtonCadastrar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jLabelCurso1 = new javax.swing.JLabel();
        jTextFieldCodCurso = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setText("CADASTRAR-SE");

        jLabelNome.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelNome.setText("Nome:");

        jTextFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldNomeActionPerformed(evt);
            }
        });

        jLabelRA.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelRA.setText("RA:");

        jLabelSenha.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelSenha.setText("Senha:");

        jLabelEmail.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelEmail.setText("E-mail:");

        jLabelCurso.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCurso.setText("Curso:");

        jComboBoxCurso.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jComboBoxCurso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Engenharia de Computacao", "Engenharia de Controle e Automacao", "Engenharia de Software", "Engenharia Elétrica", "Engenharia Eletrônica", "Engenharia Mecânica", "Licenciatura em Matemática", "Tecnologia em Análise e Desenvolvimento de Sistemas"}));

        jButtonCadastrar.setText("Concluir Cadastro");
        jButtonCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCadastrarActionPerformed(evt);
            }
        });

        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        jLabelCurso1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCurso1.setText("Código:");

        jTextFieldCodCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCodCursoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addComponent(jButtonCadastrar)
                .addGap(123, 123, 123))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButtonCancelar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelNome)
                            .addComponent(jLabelRA)
                            .addComponent(jLabelSenha)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabelCurso)
                                .addComponent(jLabelEmail)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelTitulo)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTextFieldSenha)
                                .addComponent(jTextFieldRA)
                                .addComponent(jTextFieldNome)
                                .addComponent(jTextFieldEmail)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jComboBoxCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabelCurso1)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextFieldCodCurso, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(55, 55, 55))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabelTitulo)
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldRA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelRA))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelSenha))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelEmail)
                    .addComponent(jTextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCurso)
                    .addComponent(jComboBoxCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCurso1)
                    .addComponent(jTextFieldCodCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addComponent(jButtonCadastrar)
                .addGap(46, 46, 46)
                .addComponent(jButtonCancelar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCadastrarActionPerformed
        adicionarAluno();
    }//GEN-LAST:event_jButtonCadastrarActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        cancelar();
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jTextFieldCodCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCodCursoActionPerformed
        codigoCurso();
    }//GEN-LAST:event_jTextFieldCodCursoActionPerformed

    private void jTextFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldNomeActionPerformed

    public void codigoCurso() {
        String cursoSelecionado = (String) jComboBoxCurso.getSelectedItem();
        
        if(cursoSelecionado != null) {
            switch(cursoSelecionado) {
                case "Engenharia de Computação":
                    jTextFieldCodCurso.setText("1");
                    break;
                case "Engenharia de Controle e Automação":
                    jTextFieldCodCurso.setText("2");
                    break;
                case "Engenharia de Software":
                    jTextFieldCodCurso.setText("65");
                    break;
                case "Engenharia Elétrica":
                    jTextFieldCodCurso.setText("3");
                    break;
                case "Engenharia Eletrônica":
                    jTextFieldCodCurso.setText("4");
                    break;
                case "Engenharia Mecânica":
                    jTextFieldCodCurso.setText("5");
                    break;
                case "Licenciatura em Matemática":
                    jTextFieldCodCurso.setText("6");
                    break;
                case "Tecnologia em Análise e Desenvolvimento de Sistemas":
                    jTextFieldCodCurso.setText("7");
                    break;
            }
        }
    }
    
    public void adicionarAluno() {
        Aluno aluno = new Aluno();
        
        try {
            aluno.setNome(jTextFieldNome.getText());
            aluno.setRA(Integer.parseInt(jTextFieldRA.getText()));
            aluno.setSenha(jTextFieldSenha.getText());
            aluno.setEmail(jTextFieldEmail.getText());
            aluno.setCurso((String) jComboBoxCurso.getSelectedItem());
            aluno.setCodCurso(Integer.parseInt(jTextFieldCodCurso.getText()));
            alunoDAO.adicionarAluno(aluno);
            
            PerfilAlunoGUI.geraPerfilAlunoGUI().setVisible(true);
            dispose();
            
            if(aluno != null) {
                
            }
        
        } catch(NumberFormatException nfe) {
            JOptionPane.showMessageDialog(
                    null,
                    "O valor deve ser um número!",
                    "Erro de Dados",
                    JOptionPane.ERROR_MESSAGE
            );
            jTextFieldRA.setText("");
            jTextFieldCodCurso.setText("");
        }
    }
    
    private void cancelar() {
        int resp = JOptionPane.showConfirmDialog(
            null,
            "Deseja realmente cancelar?",
            "Saída",
            JOptionPane.YES_NO_OPTION
        );
        if(resp == 0){
            SelecaoAtividadeGUI.geraSelecaoAtividadeGUI().setVisible(true);
            dispose();
        }
    }
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroAlunoGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCadastrar;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JComboBox<String> jComboBoxCurso;
    private javax.swing.JLabel jLabelCurso;
    private javax.swing.JLabel jLabelCurso1;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelRA;
    private javax.swing.JLabel jLabelSenha;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JTextField jTextFieldCodCurso;
    private javax.swing.JTextField jTextFieldEmail;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldRA;
    private javax.swing.JTextField jTextFieldSenha;
    // End of variables declaration//GEN-END:variables
}
