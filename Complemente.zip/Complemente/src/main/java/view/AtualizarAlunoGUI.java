package view;

import controller.AlunoController;
import java.awt.event.ItemEvent;
import java.sql.SQLException;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import model.Aluno;
import static org.docx4j.fonts.fop.fonts.type1.AdobeStandardEncoding.e;

public class AtualizarAlunoGUI extends javax.swing.JFrame {
    
    private static Aluno alunoAtual;
    private static AtualizarAlunoGUI atualizarAlunoUnic;
    private AlunoController alunoController = new AlunoController();
    
    private AtualizarAlunoGUI() {
        initComponents();
        jTextFieldRA.setEditable(false);
        jTextFieldCodCurso.setEditable(false);
    }
    
    public static AtualizarAlunoGUI geraAtualizarAlunoGUI(Aluno aluno) {
        if(atualizarAlunoUnic == null) {
            atualizarAlunoUnic = new AtualizarAlunoGUI();
        }
        alunoAtual = aluno;
        atualizarAlunoUnic.preencherDadosAluno();
        return atualizarAlunoUnic;
    }

    
    public void preencherDadosAluno() {
        if(alunoAtual != null) {
            jTextFieldNome.setText(alunoAtual.getNome());
            jTextFieldRA.setText(String.valueOf(alunoAtual.getRA()));
            jTextFieldEmail.setText(alunoAtual.getEmail());
            jComboBoxCurso.setSelectedItem(alunoAtual.getCurso());
            jTextFieldCodCurso.setText(String.valueOf(alunoAtual.getCodCurso()));
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelTitulo = new javax.swing.JLabel();
        jLabelNome = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jTextFieldRA = new javax.swing.JTextField();
        jLabelRA = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jTextFieldEmail = new javax.swing.JTextField();
        jLabelCurso = new javax.swing.JLabel();
        jComboBoxCurso = new javax.swing.JComboBox<>();
        jButtonAtualizar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jLabelCodCurso = new javax.swing.JLabel();
        jTextFieldCodCurso = new javax.swing.JTextField();
        jButtonAtualizar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setText("ATUALIZAR DADOS");

        jLabelNome.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelNome.setText("Nome:");

        jTextFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldNomeActionPerformed(evt);
            }
        });

        jLabelRA.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelRA.setText("RA:");

        jLabelEmail.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelEmail.setText("E-mail:");

        jLabelCurso.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCurso.setText("Curso:");

        jComboBoxCurso.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jComboBoxCurso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione uma opção", "Engenharia de Computação", "Engenharia de Controle e Automação", "Engenharia de Software", "Engenharia Elétrica", "Engenharia Eletrônica", "Engenharia Mecânica", "Licenciatura em Matemática", "Tecnologia em Análise e Desenvolvimento de Sistemas"}));
        jComboBoxCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCursoActionPerformed(evt);
            }
        });

        jButtonAtualizar.setText("Atualizar Cadastro");
        jButtonAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtualizarActionPerformed(evt);
            }
        });

        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        jLabelCodCurso.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCodCurso.setText("Código:");

        jTextFieldCodCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCodCursoActionPerformed(evt);
            }
        });

        jButtonAtualizar1.setText("Alterar Senha");
        jButtonAtualizar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtualizar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(139, 139, 139)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelEmail)
                            .addComponent(jLabelCurso))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldEmail)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jComboBoxCurso, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabelCodCurso))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(36, 36, 36)
                                        .addComponent(jButtonAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 13, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextFieldCodCurso, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelNome)
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelTitulo)
                            .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelRA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldRA)))
                .addContainerGap(139, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jButtonCancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonAtualizar1)
                .addGap(14, 14, 14))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabelTitulo)
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldRA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelRA))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelEmail)
                    .addComponent(jTextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCurso)
                    .addComponent(jComboBoxCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCodCurso)
                    .addComponent(jTextFieldCodCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(103, 103, 103)
                .addComponent(jButtonAtualizar)
                .addGap(70, 70, 70)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonCancelar)
                    .addComponent(jButtonAtualizar1))
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtualizarActionPerformed
        atualizarAluno();
    }//GEN-LAST:event_jButtonAtualizarActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        cancelar();
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jTextFieldCodCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCodCursoActionPerformed
        
    }//GEN-LAST:event_jTextFieldCodCursoActionPerformed
    
    private void jTextFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldNomeActionPerformed

    private void jButtonAtualizar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtualizar1ActionPerformed
        alterarSenha();
    }//GEN-LAST:event_jButtonAtualizar1ActionPerformed

    private void jComboBoxCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCursoActionPerformed
        codigoCurso();
    }//GEN-LAST:event_jComboBoxCursoActionPerformed

    public void alterarSenha() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JPasswordField senhaAtualField = new JPasswordField();
        JPasswordField novaSenhaField = new JPasswordField();
        JPasswordField confirmarSenhaField = new JPasswordField();

        panel.add(new JLabel("Senha atual:"));
        panel.add(senhaAtualField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("Nova senha:"));
        panel.add(novaSenhaField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("Confirmar nova senha:"));
        panel.add(confirmarSenhaField);

        int result = JOptionPane.showConfirmDialog(
                null,
                panel,
                "Alterar Senha",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            String senhaAtual = new String(senhaAtualField.getPassword());
            String novaSenha = new String(novaSenhaField.getPassword());
            String confirmarSenha = new String(confirmarSenhaField.getPassword());

            // Verificações
            if (senhaAtual.isEmpty() || novaSenha.isEmpty() || confirmarSenha.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!senhaAtual.equals(alunoAtual.getSenha())) {
                JOptionPane.showMessageDialog(null, "Senha atual incorreta.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (novaSenha.equals(senhaAtual)) {
                JOptionPane.showMessageDialog(null, "A nova senha deve ser diferente da atual.", "Erro", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (!novaSenha.equals(confirmarSenha)) {
                JOptionPane.showMessageDialog(null, "A confirmação da nova senha não confere.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                alunoAtual.setSenha(novaSenha);
                alunoController.atualizarSenha(alunoAtual.getRA(), senhaAtual, novaSenha); 
                
                JOptionPane.showMessageDialog(
                        null,
                        "Senha alterada com sucesso!",
                        "Sucesso",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,
                        "Erro ao atualizar senha: " + e.getMessage(),
                        "Erro SQL",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "Operação cancelada.",
                    "Cancelado",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }


    
    public void atualizarAluno() {
        try {
            if(jTextFieldNome.getText().isEmpty() ||
                jTextFieldEmail.getText().isEmpty() ||
                jComboBoxCurso.getSelectedItem() == null ||
                jTextFieldCodCurso.getText().isEmpty()) {
                
                JOptionPane.showMessageDialog(
                        null, 
                        "Todo os campos devem ser preenchidos!",
                        "Campos obrigatórios",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }
            
            JPasswordField passwordField = new JPasswordField();
            int option = JOptionPane.showConfirmDialog(
                    null,
                    passwordField,
                    "Digite sua senha",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (option == JOptionPane.OK_OPTION) {
                String senha = new String(passwordField.getPassword());

                if (senha.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Senha não informada. Operação cancelada.",
                            "Erro",
                            JOptionPane.ERROR_MESSAGE
                    );
                    return;
                }

                if (!senha.equals(alunoAtual.getSenha())) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Senha incorreta!",
                            "Erro",
                            JOptionPane.ERROR_MESSAGE
                    );
                    return;
                }
                
                alunoAtual.setNome(jTextFieldNome.getText());
                alunoAtual.setEmail(jTextFieldEmail.getText());
                alunoAtual.setCurso((String) jComboBoxCurso.getSelectedItem());
                alunoAtual.setCodCurso(Integer.parseInt(jTextFieldCodCurso.getText()));

                alunoController.atualizarAluno(alunoAtual);

                JOptionPane.showMessageDialog(
                        null,
                        "Os dados foram alterados com sucesso!",
                        "Sucesso",
                        JOptionPane.INFORMATION_MESSAGE
                );

                jTextFieldNome.setText("");
                jTextFieldRA.setText("");
                jTextFieldEmail.setText("");
                jComboBoxCurso.setSelectedIndex(0);
                jTextFieldCodCurso.setText("");
                
                PerfilAlunoGUI.geraPerfilAlunoGUI(alunoAtual).setVisible(true);
                dispose();
                }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "O código do curso deve ser numérico!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
        } catch (SQLException e) {
             if (e.getMessage().toLowerCase().contains("duplicate") || e.getMessage().toLowerCase().contains("unique")) {
                JOptionPane.showMessageDialog(
                        null,
                        "Este e-mail já está cadastrado por outro aluno!",
                        "Erro de e-mail duplicado",
                        JOptionPane.ERROR_MESSAGE
                );
            } else {
                JOptionPane.showMessageDialog(
                        null,
                        "Erro ao atualizar o aluno: " + e.getMessage(),
                        "Erro SQL",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    public void cancelar() {
        int resposta = JOptionPane.showConfirmDialog(
                null,
                "Deseja cancelar?",
                "Cancelar",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (resposta == JOptionPane.YES_OPTION) {
            PerfilAlunoGUI.geraPerfilAlunoGUI(alunoAtual).setVisible(true);
            dispose(); 
        }
    }
    
    public void codigoCurso() {
        String cursoSelecionado = (String) jComboBoxCurso.getSelectedItem();
        
        if(cursoSelecionado != null) {
            switch(cursoSelecionado) {
                case "Engenharia de Computação":
                    jTextFieldCodCurso.setText("41");
                    break;
                case "Engenharia de Controle e Automação":
                    jTextFieldCodCurso.setText("49");
                    break;
                case "Engenharia de Software":
                    jTextFieldCodCurso.setText("65");
                    break;
                case "Engenharia Elétrica":
                    jTextFieldCodCurso.setText("42");
                    break;
                case "Engenharia Eletrônica":
                    jTextFieldCodCurso.setText("62");
                    break;
                case "Engenharia Mecânica":
                    jTextFieldCodCurso.setText("43");
                    break;
                case "Licenciatura em Matemática":
                    jTextFieldCodCurso.setText("46");
                    break;
                case "Tecnologia em Análise e Desenvolvimento de Sistemas":
                    jTextFieldCodCurso.setText("29");
                    break;
                default:
                    jTextFieldCodCurso.setText("");
                    break;   
            }
        }
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAtualizar;
    private javax.swing.JButton jButtonAtualizar1;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JComboBox<String> jComboBoxCurso;
    private javax.swing.JLabel jLabelCodCurso;
    private javax.swing.JLabel jLabelCurso;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelRA;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JTextField jTextFieldCodCurso;
    private javax.swing.JTextField jTextFieldEmail;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldRA;
    // End of variables declaration//GEN-END:variables
}
