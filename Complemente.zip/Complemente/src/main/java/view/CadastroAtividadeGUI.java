package view;

import javax.swing.JOptionPane;

public class CadastroAtividadeGUI extends javax.swing.JFrame {
    
    private static CadastroAtividadeGUI cadastroAtividadeUnic;
    
    public static CadastroAtividadeGUI geraCadastroAtividadeGUI() {
        if(cadastroAtividadeUnic == null) {
            cadastroAtividadeUnic = new CadastroAtividadeGUI();
        }
        return cadastroAtividadeUnic;
    }
    
    public CadastroAtividadeGUI() {
        initComponents();
        configurarCampoDeData();
        jTextFieldGrupo.setEditable(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField3 = new javax.swing.JTextField();
        jLabelTitulo = new javax.swing.JLabel();
        jLabelTitulo1 = new javax.swing.JLabel();
        jLabelTipo = new javax.swing.JLabel();
        jComboBoxTipo = new javax.swing.JComboBox<>();
        jLabelGrupo = new javax.swing.JLabel();
        jTextFieldGrupo = new javax.swing.JTextField();
        jLabelDescricao = new javax.swing.JLabel();
        jTextFieldDescricao = new javax.swing.JTextField();
        jLabelPeriodo = new javax.swing.JLabel();
        jLabelTermino = new javax.swing.JLabel();
        jLabelInicio = new javax.swing.JLabel();
        jLabelDuracao = new javax.swing.JLabel();
        jTextFieldDuracao = new javax.swing.JTextField();
        jComboBoxUnidade = new javax.swing.JComboBox<>();
        jButtonCadastrar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jFormattedTextFieldTermino = new javax.swing.JFormattedTextField();
        jFormattedTextFieldInicio = new javax.swing.JFormattedTextField();
        jButtonVisualizarAtividades = new javax.swing.JButton();

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setText("REGISTRO DE ATIVIDADE");

        jLabelTitulo1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        jLabelTipo.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelTipo.setText("Tipo:");

        jComboBoxTipo.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jComboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecionar tipo",
            "Atividade esportiva",
            "Curso de língua estrangeira",
            "Atividade artística e cultural",
            "Organização de exposições e seminários de caráter artísitco e cultural",
            "Expositor em exposição artística e cultural",
            "Diretório, Centro Acadêmico, Entidade de Classe, Conselhos ou Colegiados da Instituição",
            "Trabalho voluntário, atividades comunitárias em associações",
            "Atividades beneficentes",
            "Instrutor em palestras técnicas, seminários, cursos da área específica",
            "Docente não remunerado em cursos preparatórios e reforço escolar",
            "Projetos de extensão e de interesse social",
            "Monitoria voluntária em disciplina do curso",
            "Cursos extraordinários da sua área de formação",
            "Ouvinte em palestras, congressos e seminários técnico-científicos",
            "Apresentador em palestras, congressos e seminários técnico-científicos",
            "Projetos de iniciação científica e tecnológica",
            "Expositor em exposição técnico-científico",
            "Organização de exposições e seminários de caráter acadêmico",
            "Publicação em revista técnica",
            "Publicação em anais de evento ténico-científico",
            "Publicação em periódico científico",
            "Estágio não obrigatório",
            "Trabalho com vínculo empregatício",
            "Trabalho como empreendedor na área do curso",
            "Visita técnica organizada pela UTFPR",
            "Aprovação em disciplina de enriquecimento curricular de interesse do curso",
            "Empresa Júnior, Hotel Tecnológico ou Incubadora Tecnológica",
            "Projetos multidisciplinares ou interdisciplinares",
            "Registro de patente",
            "Registro de software",
            "Outra atividade de Formação social",
            "Outra atividade de Cunho comunitário",
            "Outra atividade de Formação profissional"}));
jComboBoxTipo.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        jComboBoxTipoActionPerformed(evt);
    }
    });

    jLabelGrupo.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
    jLabelGrupo.setText("Grupo:");

    jTextFieldGrupo.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextFieldGrupoActionPerformed(evt);
        }
    });

    jLabelDescricao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
    jLabelDescricao.setText("Descrição:");

    jTextFieldDescricao.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextFieldDescricaoActionPerformed(evt);
        }
    });

    jLabelPeriodo.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
    jLabelPeriodo.setText("Período:");

    jLabelTermino.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
    jLabelTermino.setText("Término");

    jLabelInicio.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
    jLabelInicio.setText("Início");

    jLabelDuracao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
    jLabelDuracao.setText("Duração:");

    jTextFieldDuracao.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextFieldDuracaoActionPerformed(evt);
        }
    });

    jComboBoxUnidade.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
    jComboBoxUnidade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "horas", "semanas", "meses", "semestres" }));

    jButtonCadastrar.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
    jButtonCadastrar.setText("Cadastrar");

    jButtonCancelar.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
    jButtonCancelar.setText("Cancelar");
    jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButtonCancelarActionPerformed(evt);
        }
    });

    jFormattedTextFieldTermino.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jFormattedTextFieldTerminoActionPerformed(evt);
        }
    });

    jFormattedTextFieldInicio.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jFormattedTextFieldInicioActionPerformed(evt);
        }
    });

    jButtonVisualizarAtividades.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
    jButtonVisualizarAtividades.setText("Visualizar Atividades Cadastradas");

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addGap(55, 55, 55)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jButtonVisualizarAtividades)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabelDescricao)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTextFieldDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jLabelTipo)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jComboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(33, 33, 33)
                            .addComponent(jLabelGrupo)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTextFieldGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabelTermino)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jFormattedTextFieldTermino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButtonCancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonCadastrar))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelDuracao)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextFieldDuracao, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBoxUnidade, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addComponent(jLabelPeriodo)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jLabelInicio)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jFormattedTextFieldInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGap(55, 55, 55))
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(263, Short.MAX_VALUE)
                .addComponent(jLabelTitulo1)
                .addGap(105, 105, 105)))
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addGap(45, 45, 45)
            .addComponent(jLabelTitulo)
            .addGap(43, 43, 43)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabelTipo)
                .addComponent(jComboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabelGrupo)
                .addComponent(jTextFieldGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(26, 26, 26)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabelDescricao)
                .addComponent(jTextFieldDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(26, 26, 26)
            .addComponent(jLabelPeriodo)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabelInicio)
                .addComponent(jLabelTermino)
                .addComponent(jFormattedTextFieldTermino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jFormattedTextFieldInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(26, 26, 26)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabelDuracao)
                .addComponent(jTextFieldDuracao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jComboBoxUnidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(28, 28, 28)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButtonCadastrar)
                .addComponent(jButtonCancelar))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
            .addComponent(jButtonVisualizarAtividades)
            .addGap(22, 22, 22))
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabelTitulo1)
                .addContainerGap(397, Short.MAX_VALUE)))
    );

    pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldGrupoActionPerformed
        
    }//GEN-LAST:event_jTextFieldGrupoActionPerformed

    private void jTextFieldDescricaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldDescricaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldDescricaoActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextFieldDuracaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldDuracaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldDuracaoActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        cancelar();
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jFormattedTextFieldTerminoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextFieldTerminoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextFieldTerminoActionPerformed

    private void jFormattedTextFieldInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextFieldInicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextFieldInicioActionPerformed

    private void jComboBoxTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoActionPerformed
        GrupoAtividade();
    }//GEN-LAST:event_jComboBoxTipoActionPerformed

    private void cancelar() {
        int resp = JOptionPane.showConfirmDialog(
            null,
            "Deseja realmente cancelar?",
            "Saída",
            JOptionPane.YES_NO_OPTION
        );
        if(resp == 0){
            SelecaoAtividadeGUI.geraSelecaoAtividadeGUI().setVisible(true);
            dispose();
        }
    }
    
    private void GrupoAtividade() {
        String tipoSelecionado = (String) jComboBoxTipo.getSelectedItem();

        if (tipoSelecionado != null) {
            switch(tipoSelecionado) {
                /*--------GRUPO 1--------*/
                case "Outra atividade de Formação social":
                case "Atividade esportiva":
                case "Curso de língua estrangeira":
                case "Atividade artística e cultural":
                case "Organização de exposições e seminários de caráter artísitco e cultural":
                case "Expositor em exposição artística e cultural":
                    jTextFieldGrupo.setText("Grupo 1");
                    break;

                /*--------GRUPO 2--------*/
                case "Outra atividade de Cunho comunitário":
                case "Diretório, Centro Acadêmico, Entidade de Classe, Conselhos ou Colegiados da Instituição":
                case "Trabalho voluntário, atividades comunitárias em associações":
                case "Atividades beneficentes":
                case "Instrutor em palestras técnicas, seminários, cursos da área específica":
                case "Docente não remunerado em cursos preparatórios e reforço escolar":
                case "Projetos de extensão e de interesse social":
                case "Monitoria voluntária em disciplina do curso":
                    jTextFieldGrupo.setText("Grupo 2");
                    break;
                
                /*--------GRUPO 3--------*/
                case "Outra atividade de Formação profissional":
                case "Cursos extraordinários da sua área de formação":
                case "Ouvinte em palestras, congressos e seminários técnico-científicos":
                case "Apresentador em palestras, congressos e seminários técnico-científicos":
                case "Projetos de iniciação científica e tecnológica":
                case "Expositor em exposição técnico-científico":
                case "Organização de exposições e seminários de caráter acadêmico":
                case "Publicação em revista técnica":
                case "Publicação em anais de evento ténico-científico":
                case "Publicação em periódico científico":
                case "Estágio não obrigatório":
                case "Trabalho com vínculo empregatício":
                case "Trabalho como empreendedor na área do curso":
                case "Visita técnica organizada pela UTFPR":
                case "Aprovação em disciplina de enriquecimento curricular de interesse do curso":
                case "Empresa Júnior, Hotel Tecnológico ou Incubadora Tecnológica":
                case "Projetos multidisciplinares ou interdisciplinares":
                case "Registro de patente":
                case "Registro de software":
                    jTextFieldGrupo.setText("Grupo 3");
                    break;
                default:
                    jTextFieldGrupo.setText("");
                    break;
            }
        }
    }
    
    private void configurarCampoDeData() {
        try {
            javax.swing.text.MaskFormatter mascaraData = new javax.swing.text.MaskFormatter("##/##/####");
            mascaraData.setPlaceholderCharacter('_');
            
            jFormattedTextFieldInicio.setFormatterFactory(
                new javax.swing.text.DefaultFormatterFactory(mascaraData)
            );
            
            jFormattedTextFieldTermino.setFormatterFactory(
                new javax.swing.text.DefaultFormatterFactory(mascaraData)
            );
            
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroAtividadeGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCadastrar;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonVisualizarAtividades;
    private javax.swing.JComboBox<String> jComboBoxTipo;
    private javax.swing.JComboBox<String> jComboBoxUnidade;
    private javax.swing.JFormattedTextField jFormattedTextFieldInicio;
    private javax.swing.JFormattedTextField jFormattedTextFieldTermino;
    private javax.swing.JLabel jLabelDescricao;
    private javax.swing.JLabel jLabelDuracao;
    private javax.swing.JLabel jLabelGrupo;
    private javax.swing.JLabel jLabelInicio;
    private javax.swing.JLabel jLabelPeriodo;
    private javax.swing.JLabel jLabelTermino;
    private javax.swing.JLabel jLabelTipo;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JLabel jLabelTitulo1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextFieldDescricao;
    private javax.swing.JTextField jTextFieldDuracao;
    private javax.swing.JTextField jTextFieldGrupo;
    // End of variables declaration//GEN-END:variables
}
