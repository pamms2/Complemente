package view;

import controller.AtividadeController;
import java.awt.Component;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import model.Aluno;
import model.Atividade;

public class ListaAtividadesGUI extends javax.swing.JFrame {
    
    private static Aluno alunoAtual;
    private static ListaAtividadesGUI selecaoAtividadeUnic;

    public static ListaAtividadesGUI geraListaAtividadeGUI(Aluno aluno) {
        if(selecaoAtividadeUnic == null) {
            selecaoAtividadeUnic = new ListaAtividadesGUI();
        }
        alunoAtual = aluno;
        return selecaoAtividadeUnic;
    }
    
    public ListaAtividadesGUI() {
    initComponents();

    jPanelGrupo1.setLayout(new BoxLayout(jPanelGrupo1, BoxLayout.Y_AXIS));
    jPanelGrupo2.setLayout(new BoxLayout(jPanelGrupo2, BoxLayout.Y_AXIS));
    jPanelGrupo3.setLayout(new BoxLayout(jPanelGrupo3, BoxLayout.Y_AXIS));

    mostrarAtividadesDoAluno(alunoAtual);
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonGerarRelatorio = new javax.swing.JButton();
        jLabelTitulo = new javax.swing.JLabel();
        jLabelGrupo1 = new javax.swing.JLabel();
        jLabelGrupo2 = new javax.swing.JLabel();
        jLabelGrupo3 = new javax.swing.JLabel();
        jButtonAdicionarAtividade = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanelGrupo2 = new javax.swing.JPanel();
        jLabelTipo3 = new javax.swing.JLabel();
        jLabelDescricao3 = new javax.swing.JLabel();
        jLabelPeriodo3 = new javax.swing.JLabel();
        jLabelDuracao3 = new javax.swing.JLabel();
        jLabelTipoPreenchido3 = new javax.swing.JLabel();
        jLabelDescricaoPreenchido3 = new javax.swing.JLabel();
        jLabelInicio3 = new javax.swing.JLabel();
        jLabelQtd3 = new javax.swing.JLabel();
        jLabelA3 = new javax.swing.JLabel();
        jLabelTermino3 = new javax.swing.JLabel();
        jLabelTempo1 = new javax.swing.JLabel();
        jLabelPontos2 = new javax.swing.JLabel();
        jLabelQtdPontos3 = new javax.swing.JLabel();
        jCheckBoxPrimeira3 = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanelGrupo1 = new javax.swing.JPanel();
        jLabelTipo4 = new javax.swing.JLabel();
        jLabelDescricao4 = new javax.swing.JLabel();
        jLabelPeriodo4 = new javax.swing.JLabel();
        jLabelDuracao4 = new javax.swing.JLabel();
        jLabelTipoPreenchido4 = new javax.swing.JLabel();
        jLabelDescricaoPreenchido4 = new javax.swing.JLabel();
        jLabelInicio4 = new javax.swing.JLabel();
        jLabelQtd4 = new javax.swing.JLabel();
        jLabelA4 = new javax.swing.JLabel();
        jLabelTermino4 = new javax.swing.JLabel();
        jLabelTempo2 = new javax.swing.JLabel();
        jLabelPontos3 = new javax.swing.JLabel();
        jLabelQtdPontos4 = new javax.swing.JLabel();
        jCheckBoxPrimeira4 = new javax.swing.JCheckBox();
        jScrollPane4 = new javax.swing.JScrollPane();
        jPanelGrupo3 = new javax.swing.JPanel();
        jLabelTipo5 = new javax.swing.JLabel();
        jLabelDescricao5 = new javax.swing.JLabel();
        jLabelPeriodo5 = new javax.swing.JLabel();
        jLabelDuracao5 = new javax.swing.JLabel();
        jLabelTipoPreenchido5 = new javax.swing.JLabel();
        jLabelDescricaoPreenchido5 = new javax.swing.JLabel();
        jLabelInicio5 = new javax.swing.JLabel();
        jLabelQtd5 = new javax.swing.JLabel();
        jLabelA5 = new javax.swing.JLabel();
        jLabelTermino5 = new javax.swing.JLabel();
        jLabelTempo3 = new javax.swing.JLabel();
        jLabelPontos4 = new javax.swing.JLabel();
        jLabelQtdPontos5 = new javax.swing.JLabel();
        jCheckBoxPrimeira5 = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonGerarRelatorio.setText("Gerar Relatório ");
        jButtonGerarRelatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGerarRelatorioActionPerformed(evt);
            }
        });

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTitulo.setText("Lista de Atividades");

        jLabelGrupo1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo1.setText("Grupo 1");

        jLabelGrupo2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo2.setText("Grupo 2");

        jLabelGrupo3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelGrupo3.setText("Grupo 3");

        jButtonAdicionarAtividade.setText("Adicionar Atividade");
        jButtonAdicionarAtividade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdicionarAtividadeActionPerformed(evt);
            }
        });

        jLabelTipo3.setText("Tipo:");

        jLabelDescricao3.setText("Descrição:");

        jLabelPeriodo3.setText("Período:");

        jLabelDuracao3.setText("Duração:");

        jLabelTipoPreenchido3.setText("Tipo preenchido");

        jLabelDescricaoPreenchido3.setText("Descrição preenchida");

        jLabelInicio3.setText("01/01/2001");

        jLabelQtd3.setText("Qtd");

        jLabelA3.setText("a");

        jLabelTermino3.setText("31/12/2001");

        jLabelTempo1.setText("Tempo");

        jLabelPontos2.setText("Pontos:");

        jLabelQtdPontos3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQtdPontos3.setText("10");

        jCheckBoxPrimeira3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxPrimeira3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelGrupo2Layout = new javax.swing.GroupLayout(jPanelGrupo2);
        jPanelGrupo2.setLayout(jPanelGrupo2Layout);
        jPanelGrupo2Layout.setHorizontalGroup(
            jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                .addComponent(jCheckBoxPrimeira3)
                .addGap(23, 23, 23)
                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                        .addComponent(jLabelDuracao3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelQtd3, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                        .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabelDescricao3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabelTipo3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabelPeriodo3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDescricaoPreenchido3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                                .addComponent(jLabelInicio3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                                        .addComponent(jLabelTempo1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                                        .addComponent(jLabelA3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabelTermino3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabelQtdPontos3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                                .addComponent(jLabelTipoPreenchido3, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                                .addComponent(jLabelPontos2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanelGrupo2Layout.setVerticalGroup(
            jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTipo3)
                    .addComponent(jLabelTipoPreenchido3)
                    .addComponent(jLabelPontos2))
                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelDescricaoPreenchido3)
                            .addComponent(jLabelDescricao3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelPeriodo3)
                                .addComponent(jLabelInicio3)
                                .addComponent(jLabelA3)
                                .addComponent(jLabelTermino3))
                            .addComponent(jLabelQtdPontos3)))
                    .addGroup(jPanelGrupo2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jCheckBoxPrimeira3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelGrupo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDuracao3)
                    .addComponent(jLabelQtd3)
                    .addComponent(jLabelTempo1))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanelGrupo2);

        jLabelTipo4.setText("Tipo:");

        jLabelDescricao4.setText("Descrição:");

        jLabelPeriodo4.setText("Período:");

        jLabelDuracao4.setText("Duração:");

        jLabelTipoPreenchido4.setText("Tipo preenchido");

        jLabelDescricaoPreenchido4.setText("Descrição preenchida");

        jLabelInicio4.setText("01/01/2001");

        jLabelQtd4.setText("Qtd");

        jLabelA4.setText("a");

        jLabelTermino4.setText("31/12/2001");

        jLabelTempo2.setText("Tempo");

        jLabelPontos3.setText("Pontos:");

        jLabelQtdPontos4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQtdPontos4.setText("10");

        jCheckBoxPrimeira4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxPrimeira4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelGrupo1Layout = new javax.swing.GroupLayout(jPanelGrupo1);
        jPanelGrupo1.setLayout(jPanelGrupo1Layout);
        jPanelGrupo1Layout.setHorizontalGroup(
            jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                .addComponent(jCheckBoxPrimeira4)
                .addGap(23, 23, 23)
                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                        .addComponent(jLabelDuracao4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelQtd4, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                        .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabelDescricao4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabelTipo4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabelPeriodo4, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDescricaoPreenchido4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                                .addComponent(jLabelInicio4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                                        .addComponent(jLabelTempo2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                                        .addComponent(jLabelA4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabelTermino4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabelQtdPontos4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                                .addComponent(jLabelTipoPreenchido4, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                                .addComponent(jLabelPontos3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanelGrupo1Layout.setVerticalGroup(
            jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTipo4)
                    .addComponent(jLabelTipoPreenchido4)
                    .addComponent(jLabelPontos3))
                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelDescricaoPreenchido4)
                            .addComponent(jLabelDescricao4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelPeriodo4)
                                .addComponent(jLabelInicio4)
                                .addComponent(jLabelA4)
                                .addComponent(jLabelTermino4))
                            .addComponent(jLabelQtdPontos4)))
                    .addGroup(jPanelGrupo1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jCheckBoxPrimeira4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelGrupo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDuracao4)
                    .addComponent(jLabelQtd4)
                    .addComponent(jLabelTempo2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane2.setViewportView(jPanelGrupo1);

        jLabelTipo5.setText("Tipo:");

        jLabelDescricao5.setText("Descrição:");

        jLabelPeriodo5.setText("Período:");

        jLabelDuracao5.setText("Duração:");

        jLabelTipoPreenchido5.setText("Tipo preenchido");

        jLabelDescricaoPreenchido5.setText("Descrição preenchida");

        jLabelInicio5.setText("01/01/2001");

        jLabelQtd5.setText("Qtd");

        jLabelA5.setText("a");

        jLabelTermino5.setText("31/12/2001");

        jLabelTempo3.setText("Tempo");

        jLabelPontos4.setText("Pontos:");

        jLabelQtdPontos5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQtdPontos5.setText("10");

        jCheckBoxPrimeira5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxPrimeira5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelGrupo3Layout = new javax.swing.GroupLayout(jPanelGrupo3);
        jPanelGrupo3.setLayout(jPanelGrupo3Layout);
        jPanelGrupo3Layout.setHorizontalGroup(
            jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                .addComponent(jCheckBoxPrimeira5)
                .addGap(23, 23, 23)
                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                        .addComponent(jLabelDuracao5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelQtd5, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                        .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabelDescricao5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabelTipo5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabelPeriodo5, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDescricaoPreenchido5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                                .addComponent(jLabelInicio5, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                                        .addComponent(jLabelTempo3, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                                        .addComponent(jLabelA5, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabelTermino5, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabelQtdPontos5, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                                .addComponent(jLabelTipoPreenchido5, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                                .addComponent(jLabelPontos4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanelGrupo3Layout.setVerticalGroup(
            jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTipo5)
                    .addComponent(jLabelTipoPreenchido5)
                    .addComponent(jLabelPontos4))
                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelDescricaoPreenchido5)
                            .addComponent(jLabelDescricao5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelPeriodo5)
                                .addComponent(jLabelInicio5)
                                .addComponent(jLabelA5)
                                .addComponent(jLabelTermino5))
                            .addComponent(jLabelQtdPontos5)))
                    .addGroup(jPanelGrupo3Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jCheckBoxPrimeira5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelGrupo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDuracao5)
                    .addComponent(jLabelQtd5)
                    .addComponent(jLabelTempo3))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jScrollPane4.setViewportView(jPanelGrupo3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButtonAdicionarAtividade)
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButtonGerarRelatorio)
                                .addGap(32, 32, 32))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelGrupo2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelGrupo1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelGrupo3, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 486, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                        .addGap(0, 25, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(128, 128, 128)
                .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabelTitulo)
                .addGap(25, 25, 25)
                .addComponent(jLabelGrupo1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabelGrupo2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabelGrupo3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonGerarRelatorio)
                    .addComponent(jButtonAdicionarAtividade))
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGerarRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGerarRelatorioActionPerformed
        gerarRelatorio();
    }//GEN-LAST:event_jButtonGerarRelatorioActionPerformed

    private void jButtonAdicionarAtividadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdicionarAtividadeActionPerformed
        abreCadastroAtividadeGUI();
    }//GEN-LAST:event_jButtonAdicionarAtividadeActionPerformed

    private void jCheckBoxPrimeira3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxPrimeira3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxPrimeira3ActionPerformed

    private void jCheckBoxPrimeira4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxPrimeira4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxPrimeira4ActionPerformed

    private void jCheckBoxPrimeira5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxPrimeira5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxPrimeira5ActionPerformed

    public void gerarRelatorio() {
        
    }
    
    public void abreCadastroAtividadeGUI() {
        CadastroAtividadeGUI.geraCadastroAtividadeGUI(alunoAtual).setVisible(true);
        dispose();
    }
    
    public void mostrarAtividadesDoAluno(Aluno aluno) {
        jPanelGrupo1.removeAll();
        jPanelGrupo2.removeAll();
        jPanelGrupo3.removeAll();

        List<Atividade> atividades = aluno.getAtividades();

        if (atividades.isEmpty()) {
            // Mostra mensagem caso não tenha atividades em cada grupo
            jPanelGrupo1.add(new JLabel("Nenhuma atividade encontrada."));
            jPanelGrupo2.add(new JLabel("Nenhuma atividade encontrada."));
            jPanelGrupo3.add(new JLabel("Nenhuma atividade encontrada."));
        } else {
            for (Atividade a : atividades) {
                JPanel painelAtividade = criarPainelDeAtividade(a);
                switch (a.getGrupo()) {
                    case 1:
                        jPanelGrupo1.add(Box.createVerticalStrut(10));
                        jPanelGrupo1.add(painelAtividade);
                        break;
                    case 2:
                        jPanelGrupo2.add(Box.createVerticalStrut(10));
                        jPanelGrupo2.add(painelAtividade);
                        break;
                    case 3:
                        jPanelGrupo3.add(Box.createVerticalStrut(10));
                        jPanelGrupo3.add(painelAtividade);
                        break;
                    default:
                        break;
                }
            }
        }

        jPanelGrupo1.revalidate();
        jPanelGrupo1.repaint();
        jPanelGrupo2.revalidate();
        jPanelGrupo2.repaint();
        jPanelGrupo3.revalidate();
        jPanelGrupo3.repaint();
    }


    
    private JPanel criarPainelDeAtividade(Atividade a) {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createTitledBorder("Atividade ID: " + a.getId()));
        painel.setAlignmentX(Component.LEFT_ALIGNMENT); // alinhar com o layout externo

        JCheckBox checkBox = new JCheckBox("Selecionar");
        checkBox.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel tipoLabel = new JLabel("Tipo: " + a.getTipo());
        JLabel descricaoLabel = new JLabel("Descrição: " + a.getCarac().getDescricao());
        JLabel inicioLabel = new JLabel("Início: " + a.getCarac().getInicio());
        JLabel fimLabel = new JLabel("Fim: " + a.getCarac().getFim());
        JLabel duracaoLabel = new JLabel("Duração: " + a.getCarac().getDuracao() + " horas");
        JLabel pontosLabel = new JLabel("Pontos: " + a.getPontos());
        JLabel grupoLabel = new JLabel("Grupo: " + a.getGrupo());

        painel.add(checkBox);
        painel.add(tipoLabel);
        painel.add(descricaoLabel);
        painel.add(inicioLabel);
        painel.add(fimLabel);
        painel.add(duracaoLabel);
        painel.add(pontosLabel);
        painel.add(grupoLabel);

        return painel;
    }
    
    private void carregarAtividades(int ra) {
        jPanelGrupo2.setLayout(new BoxLayout(jPanelGrupo2, BoxLayout.Y_AXIS));
        
    }

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListaAtividadesGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdicionarAtividade;
    private javax.swing.JButton jButtonGerarRelatorio;
    private javax.swing.JCheckBox jCheckBoxPrimeira3;
    private javax.swing.JCheckBox jCheckBoxPrimeira4;
    private javax.swing.JCheckBox jCheckBoxPrimeira5;
    private javax.swing.JLabel jLabelA3;
    private javax.swing.JLabel jLabelA4;
    private javax.swing.JLabel jLabelA5;
    private javax.swing.JLabel jLabelDescricao3;
    private javax.swing.JLabel jLabelDescricao4;
    private javax.swing.JLabel jLabelDescricao5;
    private javax.swing.JLabel jLabelDescricaoPreenchido3;
    private javax.swing.JLabel jLabelDescricaoPreenchido4;
    private javax.swing.JLabel jLabelDescricaoPreenchido5;
    private javax.swing.JLabel jLabelDuracao3;
    private javax.swing.JLabel jLabelDuracao4;
    private javax.swing.JLabel jLabelDuracao5;
    private javax.swing.JLabel jLabelGrupo1;
    private javax.swing.JLabel jLabelGrupo2;
    private javax.swing.JLabel jLabelGrupo3;
    private javax.swing.JLabel jLabelInicio3;
    private javax.swing.JLabel jLabelInicio4;
    private javax.swing.JLabel jLabelInicio5;
    private javax.swing.JLabel jLabelPeriodo3;
    private javax.swing.JLabel jLabelPeriodo4;
    private javax.swing.JLabel jLabelPeriodo5;
    private javax.swing.JLabel jLabelPontos2;
    private javax.swing.JLabel jLabelPontos3;
    private javax.swing.JLabel jLabelPontos4;
    private javax.swing.JLabel jLabelQtd3;
    private javax.swing.JLabel jLabelQtd4;
    private javax.swing.JLabel jLabelQtd5;
    private javax.swing.JLabel jLabelQtdPontos3;
    private javax.swing.JLabel jLabelQtdPontos4;
    private javax.swing.JLabel jLabelQtdPontos5;
    private javax.swing.JLabel jLabelTempo1;
    private javax.swing.JLabel jLabelTempo2;
    private javax.swing.JLabel jLabelTempo3;
    private javax.swing.JLabel jLabelTermino3;
    private javax.swing.JLabel jLabelTermino4;
    private javax.swing.JLabel jLabelTermino5;
    private javax.swing.JLabel jLabelTipo3;
    private javax.swing.JLabel jLabelTipo4;
    private javax.swing.JLabel jLabelTipo5;
    private javax.swing.JLabel jLabelTipoPreenchido3;
    private javax.swing.JLabel jLabelTipoPreenchido4;
    private javax.swing.JLabel jLabelTipoPreenchido5;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPanel jPanelGrupo1;
    private javax.swing.JPanel jPanelGrupo2;
    private javax.swing.JPanel jPanelGrupo3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables
}
