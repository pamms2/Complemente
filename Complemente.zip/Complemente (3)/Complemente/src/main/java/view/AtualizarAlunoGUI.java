package view;

import controller.AlunoController;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Aluno;

public class AtualizarAlunoGUI extends javax.swing.JFrame {
    
    private static Aluno alunoAtual;
    private static AtualizarAlunoGUI atualizarAlunoUnic;
    private AlunoController alunoController = new AlunoController();
    
    private AtualizarAlunoGUI() {
        initComponents();
        jTextFieldRA.setEditable(false);
        jTextFieldCodCurso.setEditable(false);
    }
    
    public static AtualizarAlunoGUI geraAtualizarAlunoGUI(Aluno aluno) {
        if(atualizarAlunoUnic == null) {
            atualizarAlunoUnic = new AtualizarAlunoGUI();
        }
        alunoAtual = aluno;
        atualizarAlunoUnic.preencherDadosAluno();
        return atualizarAlunoUnic;
    }

    
    public void preencherDadosAluno() {
        if(alunoAtual != null) {
            jTextFieldNome.setText(alunoAtual.getNome());
            jTextFieldRA.setText(String.valueOf(alunoAtual.getRA()));
            jTextFieldEmail.setText(alunoAtual.getEmail());
            jComboBoxCurso.setSelectedItem(alunoAtual.getCurso());
            jTextFieldCodCurso.setText(String.valueOf(alunoAtual.getCodCurso()));
            //a senha será alterada em outra tela
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelTitulo = new javax.swing.JLabel();
        jLabelNome = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jTextFieldRA = new javax.swing.JTextField();
        jLabelRA = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jTextFieldEmail = new javax.swing.JTextField();
        jLabelCurso = new javax.swing.JLabel();
        jComboBoxCurso = new javax.swing.JComboBox<>();
        jButtonAtualizar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jLabelCodCurso = new javax.swing.JLabel();
        jTextFieldCodCurso = new javax.swing.JTextField();
        jButtonAtualizar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabelTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabelTitulo.setText("ATUALIZAR DADOS");

        jLabelNome.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelNome.setText("Nome:");

        jTextFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldNomeActionPerformed(evt);
            }
        });

        jLabelRA.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelRA.setText("RA:");

        jLabelEmail.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelEmail.setText("E-mail:");

        jLabelCurso.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCurso.setText("Curso:");

        jComboBoxCurso.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jComboBoxCurso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione uma opção", "Engenharia de Computação", "Engenharia de Controle e Automação", "Engenharia de Software", "Engenharia Elétrica", "Engenharia Eletrônica", "Engenharia Mecânica", "Licenciatura em Matemática", "Tecnologia em Análise e Desenvolvimento de Sistemas"}));

        jButtonAtualizar.setText("Atualizar Cadastro");
        jButtonAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtualizarActionPerformed(evt);
            }
        });

        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        jLabelCodCurso.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabelCodCurso.setText("Código:");

        jTextFieldCodCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCodCursoActionPerformed(evt);
            }
        });

        jButtonAtualizar1.setText("Alterar Senha");
        jButtonAtualizar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtualizar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButtonCancelar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabelEmail)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabelNome)
                                    .addComponent(jLabelRA))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabelTitulo)
                                    .addComponent(jTextFieldRA, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                                    .addComponent(jTextFieldNome)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabelCurso)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabelCodCurso)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextFieldCodCurso, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(151, 151, 151)
                        .addComponent(jButtonAtualizar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(169, 169, 169)
                        .addComponent(jButtonAtualizar1)))
                .addContainerGap(162, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabelTitulo)
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldRA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelRA))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelEmail)
                    .addComponent(jTextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCurso)
                    .addComponent(jComboBoxCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCodCurso)
                    .addComponent(jTextFieldCodCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addComponent(jButtonAtualizar)
                .addGap(64, 64, 64)
                .addComponent(jButtonAtualizar1)
                .addGap(53, 53, 53)
                .addComponent(jButtonCancelar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtualizarActionPerformed
        atualizarAluno();
    }//GEN-LAST:event_jButtonAtualizarActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        cancelar();
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jTextFieldCodCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCodCursoActionPerformed
        codigoCurso();
    }//GEN-LAST:event_jTextFieldCodCursoActionPerformed

    private void jTextFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldNomeActionPerformed

    private void jButtonAtualizar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtualizar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonAtualizar1ActionPerformed

    public void atualizarAluno() {
        try {
            if(jTextFieldNome.getText().isEmpty() ||
                jTextFieldEmail.getText().isEmpty() ||
                jComboBoxCurso.getSelectedItem() == null ||
                jTextFieldCodCurso.getText().isEmpty()) {
                
                JOptionPane.showMessageDialog(
                        null, 
                        "Todo os campos devem ser preenchidos!",
                        "Campos obrigatórios",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }
            
            String senha = JOptionPane.showInputDialog(
                    null,
                    "Digite sua senha",
                    "Confirmação de alteração",
                    JOptionPane.INFORMATION_MESSAGE
            );
            
            if(senha == null || senha.trim().isEmpty()) {
                JOptionPane.showMessageDialog(
                        null,
                        "Senha não informada. Operação cancelada.",
                        "Erro",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }
            
            if(!senha.equals(alunoAtual.getSenha())) {
                JOptionPane.showMessageDialog(
                        null,
                        "Senha incorreta!",
                        "Erro",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            } 
            
            alunoAtual.setNome(jTextFieldNome.getText());
            alunoAtual.setEmail(jTextFieldEmail.getText());
            alunoAtual.setCurso((String) jComboBoxCurso.getSelectedItem());
            alunoAtual.setCodCurso(Integer.parseInt(jTextFieldCodCurso.getText()));
            
            alunoController.atualizarAluno(alunoAtual);
            
            JOptionPane.showMessageDialog(
                    null,
                    "Os dados foram alterados com sucesso!",
                    "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE
            );
            
            PerfilAlunoGUI.geraPerfilAlunoGUI(alunoAtual).setVisible(true);
            dispose();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "O código do curso deve ser numérico!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
        } catch (SQLException e) {
             if (e.getMessage().toLowerCase().contains("duplicate") || e.getMessage().toLowerCase().contains("unique")) {
                JOptionPane.showMessageDialog(
                        null,
                        "Este e-mail já está cadastrado por outro aluno!",
                        "Erro de e-mail duplicado",
                        JOptionPane.ERROR_MESSAGE
                );
            } else {
                JOptionPane.showMessageDialog(
                        null,
                        "Erro ao atualizar o aluno: " + e.getMessage(),
                        "Erro SQL",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    public void cancelar() {
        int resposta = JOptionPane.showConfirmDialog(
                null,
                "Deseja cancelar?",
                "Cancelar",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (resposta == JOptionPane.YES_OPTION) {
            PerfilAlunoGUI.geraPerfilAlunoGUI(alunoAtual).setVisible(true);
            dispose(); 
        }
    }
    
    public void codigoCurso() {
        String cursoSelecionado = (String) jComboBoxCurso.getSelectedItem();
        
        if(cursoSelecionado != null) {
            switch(cursoSelecionado) {
                case "Engenharia de Computação":
                    jTextFieldCodCurso.setText("41");
                    break;
                case "Engenharia de Controle e Automação":
                    jTextFieldCodCurso.setText("49");
                    break;
                case "Engenharia de Software":
                    jTextFieldCodCurso.setText("65");
                    break;
                case "Engenharia Elétrica":
                    jTextFieldCodCurso.setText("42");
                    break;
                case "Engenharia Eletrônica":
                    jTextFieldCodCurso.setText("62");
                    break;
                case "Engenharia Mecânica":
                    jTextFieldCodCurso.setText("43");
                    break;
                case "Licenciatura em Matemática":
                    jTextFieldCodCurso.setText("46");
                    break;
                case "Tecnologia em Análise e Desenvolvimento de Sistemas":
                    jTextFieldCodCurso.setText("29");
                    break;
                default:
                    jTextFieldCodCurso.setText("");
                    break;   
            }
        }
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                AtualizarAlunoGUI.geraAtualizarAlunoGUI(alunoAtual).setVisible(true);
            }
        });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAtualizar;
    private javax.swing.JButton jButtonAtualizar1;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JComboBox<String> jComboBoxCurso;
    private javax.swing.JLabel jLabelCodCurso;
    private javax.swing.JLabel jLabelCurso;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelRA;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JTextField jTextFieldCodCurso;
    private javax.swing.JTextField jTextFieldEmail;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldRA;
    // End of variables declaration//GEN-END:variables
}
